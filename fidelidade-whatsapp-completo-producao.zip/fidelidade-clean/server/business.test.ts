import { describe, it, expect } from "vitest";
import {
  calculatePointsEarned,
  calculateCashbackEarned,
  calculateTier,
} from "./business";

describe("Business Logic", () => {
  describe("calculatePointsEarned", () => {
    it("should calculate points with default rate of 1 point per real", async () => {
      const points = await calculatePointsEarned(100);
      expect(points).toBe(100);
    });

    it("should apply campaign multiplier", async () => {
      const points = await calculatePointsEarned(100, 2);
      expect(points).toBe(200);
    });

    it("should handle decimal amounts", async () => {
      const points = await calculatePointsEarned(99.99);
      expect(points).toBe(99);
    });
  });

  describe("calculateCashbackEarned", () => {
    it("should calculate cashback for bronze tier", async () => {
      const cashback = await calculateCashbackEarned(100, "bronze");
      expect(parseFloat(cashback)).toBeCloseTo(5, 1);
    });

    it("should calculate cashback for prata tier", async () => {
      const cashback = await calculateCashbackEarned(100, "prata");
      expect(parseFloat(cashback)).toBeCloseTo(5, 1);
    });

    it("should calculate cashback for ouro tier", async () => {
      const cashback = await calculateCashbackEarned(100, "ouro");
      expect(parseFloat(cashback)).toBeCloseTo(5, 1);
    });

    it("should return string with 2 decimal places", async () => {
      const cashback = await calculateCashbackEarned(50, "bronze");
      expect(cashback).toMatch(/^\d+\.\d{2}$/);
    });
  });

  describe("calculateTier", () => {
    it("should return bronze for amounts below prata threshold", async () => {
      const tier = await calculateTier(1000);
      expect(tier).toBe("bronze");
    });

    it("should return prata for amounts between thresholds", async () => {
      const tier = await calculateTier(2000);
      expect(tier).toBe("prata");
    });

    it("should return ouro for amounts above ouro threshold", async () => {
      const tier = await calculateTier(4000);
      expect(tier).toBe("ouro");
    });

    it("should return bronze for zero amount", async () => {
      const tier = await calculateTier(0);
      expect(tier).toBe("bronze");
    });
  });
});
