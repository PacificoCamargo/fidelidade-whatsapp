import { z } from 'zod';
import { protectedProcedure, publicProcedure } from '../_core/trpc';
import { TRPCError } from '@trpc/server';
import {
  getSalesFrequencyAnalysis,
  createOrUpdateSalesFrequencyAnalysis,
  getAIRecommendationsByCustomerId,
  createAIRecommendation,
  getProductBehaviorAnalysis,
  createOrUpdateProductBehaviorAnalysis,
  getAIGeneratedCampaigns,
  createAIGeneratedCampaign,
  getTransactionsByCustomerId,
  getCustomerByPhone,
  getAllCustomers,
} from '../db';
import { invokeLLM } from '../_core/llm';

export const aiRouter = {
  /**
   * Analisar frequência de vendas do cliente
   * Identifica padrões de compra e risco de churn
   */
  analyzeSalesFrequency: protectedProcedure
    .input(z.object({
      customerId: z.number(),
    }))
    .mutation(async ({ input }) => {
      try {
        // Puxar histórico de transações
        const transactions = await getTransactionsByCustomerId(input.customerId, 100);
        
        if (transactions.length === 0) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Nenhuma transação encontrada para este cliente',
          });
        }

        // Calcular métricas
        const purchaseTransactions = transactions.filter(t => t.type === 'purchase');
        const purchaseDates = purchaseTransactions
          .map(t => new Date(t.createdAt).getTime())
          .sort((a, b) => b - a);

        const lastPurchaseDate = purchaseDates.length > 0 ? new Date(purchaseDates[0]) : null;
        const daysSinceLastPurchase = lastPurchaseDate 
          ? Math.floor((Date.now() - lastPurchaseDate.getTime()) / (1000 * 60 * 60 * 24))
          : null;

        // Calcular frequência média
        let averagePurchaseFrequencyDays = null;
        if (purchaseDates.length > 1) {
          const intervals = [];
          for (let i = 0; i < purchaseDates.length - 1; i++) {
            const interval = Math.floor((purchaseDates[i] - purchaseDates[i + 1]) / (1000 * 60 * 60 * 24));
            intervals.push(interval);
          }
          averagePurchaseFrequencyDays = Math.round(intervals.reduce((a, b) => a + b, 0) / intervals.length);
        }

        // Calcular total gasto
        const totalSpent = purchaseTransactions.reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);
        const averageTicket = purchaseTransactions.length > 0 ? totalSpent / purchaseTransactions.length : 0;

        // Determinar status de risco
        let riskStatus: 'healthy' | 'at_risk' | 'critical' = 'healthy';
        if (averagePurchaseFrequencyDays && daysSinceLastPurchase) {
          const daysOverdue = daysSinceLastPurchase - averagePurchaseFrequencyDays;
          if (daysOverdue > averagePurchaseFrequencyDays * 2) {
            riskStatus = 'critical';
          } else if (daysOverdue > averagePurchaseFrequencyDays) {
            riskStatus = 'at_risk';
          }
        }

        // Usar IA para gerar análise
        const aiAnalysisResponse = await invokeLLM({
          messages: [
            {
              role: 'system',
              content: 'Você é um analista de dados de fidelidade. Analise o padrão de compra do cliente e forneça insights em JSON.',
            },
            {
              role: 'user',
              content: `Analise este cliente:\n- Total de compras: ${purchaseTransactions.length}\n- Total gasto: R$ ${totalSpent.toFixed(2)}\n- Ticket médio: R$ ${averageTicket.toFixed(2)}\n- Frequência média de compras: ${averagePurchaseFrequencyDays} dias\n- Dias desde última compra: ${daysSinceLastPurchase} dias\n- Status de risco: ${riskStatus}\n\nForneça uma análise JSON com:\n{\n  "summary": "resumo da análise",\n  "recommendation": "recomendação de ação",\n  "urgency": "low|medium|high",\n  "suggestedAction": "ação específica sugerida"\n}`,
            },
          ],
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'sales_analysis',
              strict: true,
              schema: {
                type: 'object',
                properties: {
                  summary: { type: 'string' },
                  recommendation: { type: 'string' },
                  urgency: { type: 'string', enum: ['low', 'medium', 'high'] },
                  suggestedAction: { type: 'string' },
                },
                required: ['summary', 'recommendation', 'urgency', 'suggestedAction'],
                additionalProperties: false,
              },
            },
          },
        });

        const aiAnalysisContent = aiAnalysisResponse.choices[0]?.message?.content;
        const aiAnalysis = typeof aiAnalysisContent === 'string' ? aiAnalysisContent : JSON.stringify(aiAnalysisContent) || '{}';

        // Salvar análise no banco
        await createOrUpdateSalesFrequencyAnalysis({
          customerId: input.customerId,
          lastPurchaseDate,
          averagePurchaseFrequencyDays,
          daysSinceLastPurchase,
          purchaseCount: purchaseTransactions.length,
          totalSpent: totalSpent.toString(),
          averageTicket: averageTicket.toString(),
          riskStatus,
          aiAnalysis,
        });

        return {
          customerId: input.customerId,
          purchaseCount: purchaseTransactions.length,
          totalSpent,
          averageTicket,
          averagePurchaseFrequencyDays,
          daysSinceLastPurchase,
          riskStatus,
          aiAnalysis: JSON.parse(aiAnalysis),
        };
      } catch (error) {
        console.error('[AI] Erro ao analisar frequência de vendas:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Erro ao analisar frequência de vendas',
        });
      }
    }),

  /**
   * Sugerir cashback e descontos inteligentes
   * Baseado no histórico e comportamento do cliente
   */
  suggestCashback: protectedProcedure
    .input(z.object({
      customerId: z.number(),
    }))
    .mutation(async ({ input }) => {
      try {
        // Puxar análise de frequência
        const analysis = await getSalesFrequencyAnalysis(input.customerId);
        if (!analysis) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Análise de frequência não encontrada. Execute analyzeSalesFrequency primeiro.',
          });
        }

        // Usar IA para sugerir cashback
        const suggestionResponse = await invokeLLM({
          messages: [
            {
              role: 'system',
              content: 'Você é um especialista em retenção de clientes. Sugira cashback e descontos em JSON.',
            },
            {
              role: 'user',
              content: `Cliente com este perfil:\n- Status de risco: ${analysis.riskStatus}\n- Total gasto: R$ ${analysis.totalSpent}\n- Frequência: ${analysis.averagePurchaseFrequencyDays} dias\n- Dias sem comprar: ${analysis.daysSinceLastPurchase} dias\n\nSugira em JSON:\n{\n  "type": "cashback_increase|discount|free_shipping|bonus_points",\n  "currentValue": número,\n  "suggestedValue": número,\n  "reason": "motivo",\n  "confidence": 0-100\n}`,
            },
          ],
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'cashback_suggestion',
              strict: true,
              schema: {
                type: 'object',
                properties: {
                  type: { type: 'string', enum: ['cashback_increase', 'discount', 'free_shipping', 'bonus_points'] },
                  currentValue: { type: 'number' },
                  suggestedValue: { type: 'number' },
                  reason: { type: 'string' },
                  confidence: { type: 'number', minimum: 0, maximum: 100 },
                },
                required: ['type', 'suggestedValue', 'reason', 'confidence'],
                additionalProperties: false,
              },
            },
          },
        });

        const suggestionContent = suggestionResponse.choices[0]?.message?.content;
        const suggestionStr = typeof suggestionContent === 'string' ? suggestionContent : JSON.stringify(suggestionContent) || '{}';
        const suggestion = JSON.parse(suggestionStr);

        // Salvar recomendação
        const recommendation = await createAIRecommendation({
          customerId: input.customerId,
          type: suggestion.type,
          currentValue: suggestion.currentValue?.toString(),
          suggestedValue: suggestion.suggestedValue?.toString(),
          reason: suggestion.reason,
          confidence: suggestion.confidence,
          aiInsight: JSON.stringify(suggestion),
        });

        return {
          id: (recommendation as any).insertId || 0,
          ...suggestion,
        };
      } catch (error) {
        console.error('[AI] Erro ao sugerir cashback:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Erro ao sugerir cashback',
        });
      }
    }),

  /**
   * Analisar comportamento de compra por categoria de produto
   * Identifica oportunidades de cross-sell e upsell
   */
  analyzeProductBehavior: protectedProcedure
    .input(z.object({
      customerId: z.number(),
      productCategory: z.string(),
    }))
    .mutation(async ({ input }) => {
      try {
        // Puxar transações
        const transactions = await getTransactionsByCustomerId(input.customerId, 100);
        const categoryTransactions = transactions.filter(t => t.description?.includes(input.productCategory));

        const purchaseCount = categoryTransactions.length;
        const totalSpent = categoryTransactions.reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);
        const lastPurchaseDate = categoryTransactions.length > 0 
          ? new Date(categoryTransactions[0].createdAt)
          : null;

        // Calcular frequência
        let averagePurchaseFrequencyDays = null;
        if (categoryTransactions.length > 1) {
          const dates = categoryTransactions.map(t => new Date(t.createdAt).getTime()).sort((a, b) => b - a);
          const intervals = [];
          for (let i = 0; i < dates.length - 1; i++) {
            intervals.push(Math.floor((dates[i] - dates[i + 1]) / (1000 * 60 * 60 * 24)));
          }
          averagePurchaseFrequencyDays = Math.round(intervals.reduce((a, b) => a + b, 0) / intervals.length);
        }

        // Usar IA para análise
        const analysisResponse = await invokeLLM({
          messages: [
            {
              role: 'system',
              content: 'Você é um especialista em recomendações de produtos. Analise o comportamento de compra em JSON.',
            },
            {
              role: 'user',
              content: `Cliente - Categoria: ${input.productCategory}\n- Compras: ${purchaseCount}\n- Total gasto: R$ ${totalSpent.toFixed(2)}\n- Frequência: ${averagePurchaseFrequencyDays} dias\n\nSugira em JSON:\n{\n  "recommendedProducts": ["produto1", "produto2"],\n  "crossSellOpportunity": "descrição",\n  "upsellOpportunity": "descrição",\n  "conversionProbability": 0-100\n}`,
            },
          ],
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'product_analysis',
              strict: true,
              schema: {
                type: 'object',
                properties: {
                  recommendedProducts: { type: 'array', items: { type: 'string' } },
                  crossSellOpportunity: { type: 'string' },
                  upsellOpportunity: { type: 'string' },
                  conversionProbability: { type: 'number', minimum: 0, maximum: 100 },
                },
                required: ['recommendedProducts', 'crossSellOpportunity', 'upsellOpportunity', 'conversionProbability'],
                additionalProperties: false,
              },
            },
          },
        });

        const analysisContent = analysisResponse.choices[0]?.message?.content;
        const analysisStr = typeof analysisContent === 'string' ? analysisContent : JSON.stringify(analysisContent) || '{}';
        const analysis = JSON.parse(analysisStr);

        // Salvar análise
        await createOrUpdateProductBehaviorAnalysis({
          customerId: input.customerId,
          productCategory: input.productCategory,
          purchaseCount,
          totalSpent: totalSpent.toString(),
          lastPurchaseDate,
          averagePurchaseFrequencyDays,
          recommendedProducts: JSON.stringify(analysis.recommendedProducts),
          crossSellOpportunity: analysis.crossSellOpportunity,
          upsellOpportunity: analysis.upsellOpportunity,
          conversionProbability: analysis.conversionProbability,
          aiAnalysis: JSON.stringify(analysis),
        });

        return {
          customerId: input.customerId,
          productCategory: input.productCategory,
          purchaseCount,
          totalSpent,
          ...analysis,
        };
      } catch (error) {
        console.error('[AI] Erro ao analisar comportamento de produtos:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Erro ao analisar comportamento de produtos',
        });
      }
    }),

  /**
   * Gerar campanhas automáticas com IA
   * Baseado em análise de vendas e recomendações
   */
  generateCampaigns: protectedProcedure
    .input(z.object({
      userId: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        // Puxar todos os clientes
        const customers = await getAllCustomers(1000);
        
        if (customers.length === 0) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'Nenhum cliente encontrado',
          });
        }

        // Usar IA para gerar campanha
        const campaignResponse = await invokeLLM({
          messages: [
            {
              role: 'system',
              content: 'Você é um especialista em marketing. Gere uma campanha de fidelidade em JSON.',
            },
            {
              role: 'user',
              content: `Temos ${customers.length} clientes no programa de fidelidade.\nGere uma campanha em JSON:\n{\n  "name": "nome da campanha",\n  "targetSegment": "segment",\n  "messageTemplate": "mensagem",\n  "cashbackBonus": número,\n  "pointsMultiplier": número,\n  "projectedRevenue": número\n}`,
            },
          ],
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'campaign',
              strict: true,
              schema: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  targetSegment: { type: 'string' },
                  messageTemplate: { type: 'string' },
                  cashbackBonus: { type: 'number' },
                  pointsMultiplier: { type: 'number' },
                  projectedRevenue: { type: 'number' },
                },
                required: ['name', 'targetSegment', 'messageTemplate', 'cashbackBonus', 'pointsMultiplier', 'projectedRevenue'],
                additionalProperties: false,
              },
            },
          },
        });

        const campaignContent = campaignResponse.choices[0]?.message?.content;
        const campaignStr = typeof campaignContent === 'string' ? campaignContent : JSON.stringify(campaignContent) || '{}';
        const campaign = JSON.parse(campaignStr);

        // Salvar campanha
        const result = await createAIGeneratedCampaign({
          userId: input.userId,
          name: campaign.name,
          targetSegment: campaign.targetSegment,
          targetAudience: customers.length,
          messageTemplate: campaign.messageTemplate,
          cashbackBonus: campaign.cashbackBonus?.toString(),
          pointsMultiplier: campaign.pointsMultiplier,
          projectedRevenue: campaign.projectedRevenue?.toString(),
          aiInsight: JSON.stringify(campaign),
        });

        return {
          id: (result as any).insertId || 0,
          ...campaign,
          targetAudience: customers.length,
        };
      } catch (error) {
        console.error('[AI] Erro ao gerar campanhas:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Erro ao gerar campanhas',
        });
      }
    }),

  /**
   * Obter recomendações de IA para um cliente
   */
  getRecommendations: protectedProcedure
    .input(z.object({
      customerId: z.number(),
    }))
    .query(async ({ input }) => {
      try {
        const recommendations = await getAIRecommendationsByCustomerId(input.customerId);
        return recommendations.map(r => ({
          id: r.id,
          type: r.type,
          currentValue: r.currentValue,
          suggestedValue: r.suggestedValue,
          reason: r.reason,
          confidence: r.confidence,
          status: r.status,
          createdAt: r.createdAt,
        }));
      } catch (error) {
        console.error('[AI] Erro ao obter recomendações:', error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: 'Erro ao obter recomendações',
        });
      }
    }),
};
