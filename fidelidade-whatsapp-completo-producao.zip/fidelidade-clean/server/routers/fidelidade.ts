import { router, publicProcedure, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import {
  getCustomerByPhone,
  getAllCustomers,
  createCustomer,
  updateCustomer,
  getWalletByCustomerId,
  createWallet,
  getTransactionsByCustomerId,
  getAllRewards,
  createReward,
  updateReward,
  createRedemption,
  getRedemptionsByCustomerId,
  updateRedemption,
  getAllCampaigns,
  createCampaign,
  updateCampaign,
  getRulesConfig,
  createRulesConfig,
  updateRulesConfig,
} from "../db";
import {
  processPurchase,
  redeemPoints,
  useCashback,
  addBirthdayBonus,
  addFirstPurchaseBonus,
} from "../business";
import { importSalesData, type SalesImportRow } from "../importers/sales-importer";
import { importStockData, type StockImportRow } from "../importers/stock-importer";
import { importCustomersData, type CustomerImportRow } from "../importers/customers-importer";
import { nanoid } from "nanoid";

export const fidelidadeRouter = router({
  getCustomerByPhone: publicProcedure
    .input(z.object({ phone: z.string() }))
    .query(async ({ input }) => {
      return await getCustomerByPhone(input.phone);
    }),

  listCustomers: protectedProcedure
    .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      return await getAllCustomers(input.limit, input.offset);
    }),

  createCustomer: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        phone: z.string(),
        email: z.string().optional(),
        birthDate: z.date().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const existing = await getCustomerByPhone(input.phone);
      if (existing) {
        throw new Error("Customer with this phone already exists");
      }

      const result = await createCustomer({
        name: input.name,
        phone: input.phone,
        email: input.email,
        birthDate: input.birthDate,
        status: "active",
        tier: "bronze",
        totalSpent: "0",
      });

      const customer = await getCustomerByPhone(input.phone);
      if (customer) {
        await createWallet(customer.id);
      }

      return customer;
    }),

  updateCustomer: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().optional(),
        email: z.string().optional(),
        status: z.enum(["active", "inactive"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      await updateCustomer(input.id, {
        name: input.name,
        email: input.email,
        status: input.status as any,
      });
      return { success: true };
    }),

  getWallet: publicProcedure
    .input(z.object({ customerId: z.number() }))
    .query(async ({ input }) => {
      return await getWalletByCustomerId(input.customerId);
    }),

  getTransactions: publicProcedure
    .input(z.object({ customerId: z.number(), limit: z.number().default(50), offset: z.number().default(0) }))
    .query(async ({ input }) => {
      return await getTransactionsByCustomerId(input.customerId, input.limit, input.offset);
    }),

  processPurchase: protectedProcedure
    .input(
      z.object({
        customerId: z.number(),
        amount: z.number().positive(),
        orderId: z.string().optional(),
        campaignMultiplier: z.number().default(1),
      })
    )
    .mutation(async ({ input }) => {
      return await processPurchase(
        input.customerId,
        input.amount,
        input.orderId,
        input.campaignMultiplier
      );
    }),

  redeemPoints: protectedProcedure
    .input(z.object({ customerId: z.number(), pointsToRedeem: z.number().positive() }))
    .mutation(async ({ input }) => {
      return await redeemPoints(input.customerId, input.pointsToRedeem);
    }),

  useCashback: protectedProcedure
    .input(z.object({ customerId: z.number(), cashbackAmount: z.number().positive() }))
    .mutation(async ({ input }) => {
      return await useCashback(input.customerId, input.cashbackAmount);
    }),

  addBirthdayBonus: protectedProcedure
    .input(z.object({ customerId: z.number() }))
    .mutation(async ({ input }) => {
      return await addBirthdayBonus(input.customerId);
    }),

  addFirstPurchaseBonus: protectedProcedure
    .input(z.object({ customerId: z.number() }))
    .mutation(async ({ input }) => {
      return await addFirstPurchaseBonus(input.customerId);
    }),

  listRewards: publicProcedure.query(async () => {
    return await getAllRewards();
  }),

  createReward: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        type: z.enum(["discount", "cashback", "gift", "experience"]),
        value: z.number().positive(),
        pointsRequired: z.number().positive(),
        expirationDays: z.number().default(90),
      })
    )
    .mutation(async ({ input }) => {
      return await createReward({
        name: input.name,
        type: input.type,
        value: input.value.toString() as any,
        pointsRequired: input.pointsRequired,
        expirationDays: input.expirationDays,
        active: true,
      });
    }),

  updateReward: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        active: z.boolean().optional(),
        value: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      await updateReward(input.id, {
        active: input.active,
        value: input.value?.toString() as any,
      });
      return { success: true };
    }),

  getRedemptions: publicProcedure
    .input(z.object({ customerId: z.number() }))
    .query(async ({ input }) => {
      return await getRedemptionsByCustomerId(input.customerId);
    }),

  redeemReward: protectedProcedure
    .input(z.object({ customerId: z.number(), rewardId: z.number() }))
    .mutation(async ({ input }) => {
      const code = nanoid(12);
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30);

      return await createRedemption({
        customerId: input.customerId,
        rewardId: input.rewardId,
        code,
        expiresAt,
        status: "pending",
      });
    }),

  updateRedemption: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["pending", "used", "expired", "cancelled"]),
      })
    )
    .mutation(async ({ input }) => {
      const usedAt = input.status === "used" ? new Date() : undefined;
      await updateRedemption(input.id, {
        status: input.status as any,
        usedAt,
      });
      return { success: true };
    }),

  listCampaigns: protectedProcedure.query(async () => {
    return await getAllCampaigns();
  }),

  createCampaign: protectedProcedure
    .input(
      z.object({
        name: z.string(),
        type: z.enum(["reactivation", "last_chance", "nps", "promo", "birthday", "first_purchase"]),
        segment: z.string().optional(),
        triggerRule: z.string().optional(),
        messageTemplate: z.string().optional(),
        pointsMultiplier: z.number().default(1),
        cashbackBonus: z.number().default(0),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await createCampaign({
        name: input.name,
        type: input.type,
        segment: input.segment,
        triggerRule: input.triggerRule,
        messageTemplate: input.messageTemplate,
        pointsMultiplier: input.pointsMultiplier,
        cashbackBonus: input.cashbackBonus.toString() as any,
        active: true,
        startDate: input.startDate,
        endDate: input.endDate,
      });
    }),

  updateCampaign: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        active: z.boolean().optional(),
        pointsMultiplier: z.number().optional(),
        cashbackBonus: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      await updateCampaign(input.id, {
        active: input.active,
        pointsMultiplier: input.pointsMultiplier,
        cashbackBonus: input.cashbackBonus?.toString() as any,
      });
      return { success: true };
    }),

  getRulesConfig: protectedProcedure.query(async () => {
    return await getRulesConfig();
  }),

  updateRulesConfig: protectedProcedure
    .input(
      z.object({
        pointsPerReal: z.number().optional(),
        cashbackPercentage: z.number().optional(),
        pointsExpirationDays: z.number().optional(),
        bronzeCashback: z.number().optional(),
        prataThreshold: z.number().optional(),
        prataCashback: z.number().optional(),
        ouroThreshold: z.number().optional(),
        ouroCashback: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const config = await getRulesConfig();
      if (!config) {
        await createRulesConfig({
          name: "default",
          pointsPerReal: input.pointsPerReal?.toString() as any,
          cashbackPercentage: input.cashbackPercentage?.toString() as any,
          pointsExpirationDays: input.pointsExpirationDays,
          bronzeCashback: input.bronzeCashback?.toString() as any,
          prataThreshold: input.prataThreshold?.toString() as any,
          prataCashback: input.prataCashback?.toString() as any,
          ouroThreshold: input.ouroThreshold?.toString() as any,
          ouroCashback: input.ouroCashback?.toString() as any,
        });
      } else {
        await updateRulesConfig(config.id, {
          pointsPerReal: input.pointsPerReal?.toString() as any,
          cashbackPercentage: input.cashbackPercentage?.toString() as any,
          pointsExpirationDays: input.pointsExpirationDays,
          bronzeCashback: input.bronzeCashback?.toString() as any,
          prataThreshold: input.prataThreshold?.toString() as any,
          prataCashback: input.prataCashback?.toString() as any,
          ouroThreshold: input.ouroThreshold?.toString() as any,
          ouroCashback: input.ouroCashback?.toString() as any,
        });
      }
      return { success: true };
    }),

  importExcelData: protectedProcedure
    .input(
      z.object({
        customers: z.array(z.any()).default([]),
        sales: z.array(z.any()).default([]),
        stock: z.array(z.any()).default([]),
      })
    )
    .mutation(async ({ input }) => {
      let customersImported = 0;
      let salesImported = 0;
      let stockImported = 0;

      // Importar vendas com novo importador robusto
      if (input.sales && input.sales.length > 0) {
        try {
          const result = await importSalesData(input.sales as SalesImportRow[]);
          customersImported = result.customersCreated;
          salesImported = result.salesProcessed;
        } catch (err) {
          console.error('Erro ao importar vendas:', err);
        }
      }

      // Importar estoque com novo importador robusto
      if (input.stock && input.stock.length > 0) {
        try {
          const result = await importStockData(input.stock as StockImportRow[]);
          stockImported = result.productsCreated + result.productsUpdated;
        } catch (err) {
          console.error('Erro ao importar estoque:', err);
        }
      }

      // Importar clientes com novo importador robusto
      if (input.customers && input.customers.length > 0) {
        try {
          const result = await importCustomersData(input.customers as CustomerImportRow[]);
          customersImported = result.customersCreated + result.customersUpdated;
        } catch (err) {
          console.error('Erro ao importar clientes:', err);
        }
      }

      return {
        customersImported,
        salesImported,
        stockImported,
        message: 'Dados importados com sucesso',
      };
    }),
});
