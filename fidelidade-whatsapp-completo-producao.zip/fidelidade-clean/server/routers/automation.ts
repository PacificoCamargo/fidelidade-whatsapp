import { protectedProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getDb } from "../db";
import { automationTriggers, automationLogs } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { processTriggers } from "../automation";

export const automationRouter = router({
  /**
   * Cria um novo trigger de automação
   */
  createTrigger: protectedProcedure
    .input(
      z.object({
        name: z.string().min(1).max(255),
        triggerType: z.enum([
          "points_accumulated",
          "cashback_available",
          "points_expiring",
          "birthday",
          "tier_upgrade",
          "purchase_milestone",
        ]),
        messageTemplate: z.string().min(1),
        conditions: z.any().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.insert(automationTriggers).values({
          userId: ctx.user.id,
          name: input.name,
          triggerType: input.triggerType,
          messageTemplate: input.messageTemplate,
          conditions: input.conditions ? JSON.stringify(input.conditions) : null,
          isActive: true,
          nextExecution: new Date(),
        });

        return { success: true, message: "Trigger criado com sucesso" };
      } catch (error) {
        console.error("[Automation Router] Erro ao criar trigger:", error);
        throw new Error("Erro ao criar trigger");
      }
    }),

  /**
   * Lista todos os triggers do usuário
   */
  listTriggers: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const triggers = await db
        .select()
        .from(automationTriggers)
        .where(eq(automationTriggers.userId, ctx.user.id));

      return {
        triggers: triggers.map((t) => ({
          id: t.id,
          name: t.name,
          triggerType: t.triggerType,
          isActive: t.isActive,
          messageTemplate: t.messageTemplate,
          conditions: t.conditions ? JSON.parse(t.conditions) : {},
          lastExecuted: t.lastExecuted,
          nextExecution: t.nextExecution,
          executionCount: t.executionCount,
          createdAt: t.createdAt,
        })),
      };
    } catch (error) {
      console.error("[Automation Router] Erro ao listar triggers:", error);
      throw new Error("Erro ao listar triggers");
    }
  }),

  /**
   * Obtém um trigger específico
   */
  getTrigger: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const trigger = await db
          .select()
          .from(automationTriggers)
          .where(eq(automationTriggers.id, input.id))
          .limit(1);

        if (!trigger.length || trigger[0].userId !== ctx.user.id) {
          throw new Error("Trigger não encontrado");
        }

        const t = trigger[0];
        return {
          trigger: {
            id: t.id,
            name: t.name,
            triggerType: t.triggerType,
            isActive: t.isActive,
            messageTemplate: t.messageTemplate,
            conditions: t.conditions ? JSON.parse(t.conditions) : {},
            lastExecuted: t.lastExecuted,
            nextExecution: t.nextExecution,
            executionCount: t.executionCount,
            createdAt: t.createdAt,
          },
        };
      } catch (error) {
        console.error("[Automation Router] Erro ao obter trigger:", error);
        throw new Error("Erro ao obter trigger");
      }
    }),

  /**
   * Atualiza um trigger
   */
  updateTrigger: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(255).optional(),
        messageTemplate: z.string().min(1).optional(),
        conditions: z.any().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Verificar permissão
        const trigger = await db
          .select()
          .from(automationTriggers)
          .where(eq(automationTriggers.id, input.id))
          .limit(1);

        if (!trigger.length || trigger[0].userId !== ctx.user.id) {
          throw new Error("Trigger não encontrado");
        }

        const updateData: any = {};
        if (input.name) updateData.name = input.name;
        if (input.messageTemplate) updateData.messageTemplate = input.messageTemplate;
        if (input.conditions) updateData.conditions = JSON.stringify(input.conditions);
        if (input.isActive !== undefined) updateData.isActive = input.isActive;

        await db
          .update(automationTriggers)
          .set(updateData)
          .where(eq(automationTriggers.id, input.id));

        return { success: true, message: "Trigger atualizado com sucesso" };
      } catch (error) {
        console.error("[Automation Router] Erro ao atualizar trigger:", error);
        throw new Error("Erro ao atualizar trigger");
      }
    }),

  /**
   * Deleta um trigger
   */
  deleteTrigger: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Verificar permissão
        const trigger = await db
          .select()
          .from(automationTriggers)
          .where(eq(automationTriggers.id, input.id))
          .limit(1);

        if (!trigger.length || trigger[0].userId !== ctx.user.id) {
          throw new Error("Trigger não encontrado");
        }

        await db.delete(automationTriggers).where(eq(automationTriggers.id, input.id));

        return { success: true, message: "Trigger deletado com sucesso" };
      } catch (error) {
        console.error("[Automation Router] Erro ao deletar trigger:", error);
        throw new Error("Erro ao deletar trigger");
      }
    }),

  /**
   * Executa triggers manualmente
   */
  executeTriggers: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      await processTriggers();
      return { success: true, message: "Triggers executados com sucesso" };
    } catch (error) {
      console.error("[Automation Router] Erro ao executar triggers:", error);
      throw new Error("Erro ao executar triggers");
    }
  }),

  /**
   * Obtém logs de execução de um trigger
   */
  getTriggerLogs: protectedProcedure
    .input(
      z.object({
        triggerId: z.number(),
        limit: z.number().default(50),
      })
    )
    .query(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Verificar permissão
        const trigger = await db
          .select()
          .from(automationTriggers)
          .where(eq(automationTriggers.id, input.triggerId))
          .limit(1);

        if (!trigger.length || trigger[0].userId !== ctx.user.id) {
          throw new Error("Trigger não encontrado");
        }

        const logs = await db
          .select()
          .from(automationLogs)
          .where(eq(automationLogs.triggerId, input.triggerId))
          .limit(input.limit);

        return { logs };
      } catch (error) {
        console.error("[Automation Router] Erro ao obter logs:", error);
        throw new Error("Erro ao obter logs");
      }
    }),
});
