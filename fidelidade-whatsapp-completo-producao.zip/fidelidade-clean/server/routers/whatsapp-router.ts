import { router, protectedProcedure } from "../_core/trpc";
import { z } from "zod";
import { 
  initializeWhatsApp, 
  sendMessage, 
  sendBulkMessages, 
  getWhatsAppStatus,
  disconnectWhatsApp 
} from "../whatsapp-web";
import {
  initiatePairing,
  getPairingStatus,
  isConnected,
  disconnectWhatsApp as disconnectPairing,
} from "../whatsapp-pairing";
import {
  generateWhatsAppQRCode,
  isQRCodeValid,
} from "../whatsapp-qrcode";

export const whatsappRouter = router({
  // Conectar WhatsApp
  connect: protectedProcedure.mutation(async () => {
    try {
      await initializeWhatsApp();
      return { success: true, message: "Conectando WhatsApp..." };
    } catch (err) {
      return { 
        success: false, 
        message: (err as Error).message || "Erro ao conectar" 
      };
    }
  }),

  // Obter status da conexão
  getStatus: protectedProcedure.query(async () => {
    return getWhatsAppStatus();
  }),

  // Enviar mensagem única
  sendMessage: protectedProcedure
    .input(z.object({
      phoneNumber: z.string(),
      message: z.string(),
    }))
    .mutation(async ({ input }) => {
      try {
        await sendMessage(input.phoneNumber, input.message);
        return { success: true, message: "Mensagem enviada com sucesso" };
      } catch (err) {
        return { 
          success: false, 
          message: (err as Error).message || "Erro ao enviar mensagem" 
        };
      }
    }),

  // Enviar mensagens em massa
  sendBulkMessages: protectedProcedure
    .input(z.object({
      recipients: z.array(z.object({
        phone: z.string(),
        name: z.string(),
      })),
      message: z.string(),
      delayMs: z.number().default(1000),
    }))
    .mutation(async ({ input }) => {
      try {
        const results = await sendBulkMessages(
          input.recipients,
          input.message,
          input.delayMs
        );
        
        const successful = results.filter(r => r.status === 'sent').length;
        const failed = results.filter(r => r.status === 'error').length;

        return {
          success: true,
          message: `${successful} mensagens enviadas, ${failed} falharam`,
          results,
          stats: { successful, failed, total: results.length },
        };
      } catch (err) {
        return { 
          success: false, 
          message: (err as Error).message || "Erro ao enviar mensagens em massa" 
        };
      }
    }),

  // Desconectar WhatsApp
  disconnect: protectedProcedure.mutation(async () => {
    try {
      disconnectWhatsApp();
      return { success: true, message: "WhatsApp desconectado" };
    } catch (err) {
      return { 
        success: false, 
        message: (err as Error).message || "Erro ao desconectar" 
      };
    }
  }),

  // Iniciar pareamento com código
  initiatePairing: protectedProcedure
    .input(z.object({
      phoneNumber: z.string(),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await initiatePairing(input.phoneNumber);
        return { 
          success: true, 
          message: "Código de pareamento gerado",
          pairingCode: result.pairingCode,
          pairingLink: result.pairingLink,
        };
      } catch (err) {
        return { 
          success: false, 
          message: (err as Error).message || "Erro ao gerar código de pareamento" 
        };
      }
    }),

  // Verificar status do pareamento
  checkPairingStatus: protectedProcedure.query(async () => {
    const status = getPairingStatus();
    return {
      pairingCode: status.pairingCode,
      isConnected: status.isConnected,
      phoneNumber: status.phoneNumber,
    };
  }),

  // Verificar se está conectado
  isPairingConnected: protectedProcedure.query(async () => {
    return {
      isConnected: isConnected(),
    };
  }),

  // Desconectar pareamento
  disconnectPairing: protectedProcedure.mutation(async () => {
    try {
      await disconnectPairing();
      return { success: true, message: "WhatsApp desconectado com sucesso" };
    } catch (err) {
      return { 
        success: false, 
        message: (err as Error).message || "Erro ao desconectar" 
      };
    }
  }),

  // Gerar QR Code - Stateless e Serverless-Compatible
  generateQRCode: protectedProcedure
    .input(z.object({
      phoneNumber: z.string(),
    }))
    .mutation(async ({ input }) => {
      try {
        const result = await generateWhatsAppQRCode(input.phoneNumber);
        return {
          success: true,
          message: "QR Code gerado com sucesso",
          qrCodeBase64: result.qrCodeBase64,
          qrCodeDataUrl: result.qrCodeDataUrl,
          expiresIn: result.expiresIn,
          timestamp: result.timestamp,
        };
      } catch (err) {
        return {
          success: false,
          message: (err as Error).message || "Erro ao gerar QR Code",
        };
      }
    }),

  // Validar se um QR Code ainda eh valido
  validateQRCode: protectedProcedure
    .input(z.object({
      timestamp: z.number(),
      expiresIn: z.number(),
    }))
    .query(({ input }) => {
      const isValid = isQRCodeValid(input.timestamp, input.expiresIn);
      return {
        isValid,
        message: isValid ? "QR Code ainda eh valido" : "QR Code expirou",
      };
    }),
});
