/**
 * Importador de Estoque
 * Processa arquivo de estoque em formato Excel
 * Valida dados, trata estoques negativos como 0, e atualiza catálogo de produtos
 */

import { getDb } from "../db";
import { products } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export interface StockImportRow {
  Código?: number | string;
  "Cód. Barras"?: string;
  Descrição?: string;
  "Desc."?: string;
  "Tam."?: string;
  Tamanho?: string;
  Cor?: string;
  Qtd?: number | string;
  Quantidade?: number | string;
  Unitário?: number | string;
  "Preço Unitário"?: number | string;
  Fornecedor?: string;
  Categoria?: string;
  Status?: string;
  Marca?: string;
  Custo?: number | string;
  "À Vista"?: number | string;
  [key: string]: any;
}

export interface StockImportResult {
  productsCreated: number;
  productsUpdated: number;
  errors: Array<{ row: number; error: string }>;
  summary: {
    totalProducts: number;
    totalValue: number;
    negativeStockFixed: number;
  };
}

/**
 * Extrai valor numérico
 */
function parseValue(value: any): number {
  if (typeof value === "number") return value;
  if (typeof value === "string") {
    const parsed = parseFloat(value.replace(",", "."));
    return isNaN(parsed) ? 0 : parsed;
  }
  return 0;
}

/**
 * Valida e normaliza quantidade (trata negativo como 0)
 */
function normalizeQuantity(quantity: any): number {
  const qty = typeof quantity === "string" ? parseInt(quantity, 10) : Number(quantity);
  if (isNaN(qty)) return 0;
  // Se negativo, retorna 0
  return qty < 0 ? 0 : qty;
}

/**
 * Normaliza descrição do produto
 */
function normalizeDescription(desc: any): string {
  if (!desc) return "Produto sem descrição";
  return String(desc).trim().substring(0, 500);
}

/**
 * Normaliza código do produto
 */
function normalizeCode(code: any): string | null {
  if (!code) return null;
  const normalized = String(code).trim();
  if (normalized.length === 0) return null;
  return normalized;
}

/**
 * Normaliza linha de estoque
 */
function normalizeStockRow(row: StockImportRow) {
  const code = normalizeCode(row.Código);
  if (!code) {
    return null;
  }

  return {
    code,
    barcode: row["Cód. Barras"] ? String(row["Cód. Barras"]).trim() : undefined,
    description: normalizeDescription(row.Descrição || row["Desc."]),
    size: row["Tam."] || row.Tamanho ? String(row["Tam."] || row.Tamanho).trim() : undefined,
    color: row.Cor ? String(row.Cor).trim() : undefined,
    quantity: normalizeQuantity(row.Qtd || row.Quantidade),
    unitPrice: parseValue(row.Unitário || row["Preço Unitário"]),
    costPrice: parseValue(row.Custo),
    salePrice: parseValue(row["À Vista"] || row.Unitário || row["Preço Unitário"]),
    supplier: row.Fornecedor ? String(row.Fornecedor).trim() : undefined,
    category: row.Categoria ? String(row.Categoria).trim() : undefined,
    status: (row.Status || "active").toLowerCase() === "ativo" ? "active" : "inactive",
    brand: row.Marca ? String(row.Marca).trim() : undefined,
  };
}

/**
 * Importa estoque do arquivo
 */
export async function importStockData(rows: StockImportRow[]): Promise<StockImportResult> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database connection failed");
  }
  const result: StockImportResult = {
    productsCreated: 0,
    productsUpdated: 0,
    errors: [],
    summary: {
      totalProducts: 0,
      totalValue: 0,
      negativeStockFixed: 0,
    },
  };

  for (let i = 0; i < rows.length; i++) {
    try {
      const row = rows[i];
      if (!row || Object.keys(row).length === 0) continue;

      // Normalizar dados
      const normalized = normalizeStockRow(row);
      if (!normalized) {
        result.errors.push({
          row: i + 2,
          error: "Código do produto inválido ou não preenchido",
        });
        continue;
      }

      // Validar dados essenciais
      if (normalized.unitPrice <= 0 && normalized.salePrice <= 0) {
        result.errors.push({
          row: i + 2,
          error: "Preço unitário ou preço à vista deve ser maior que zero",
        });
        continue;
      }

      // Rastrear estoque negativo corrigido
      const qtdValue = normalizeQuantity(row.Qtd || row.Quantidade);
      const originalQtd = normalizeQuantity(row.Qtd || row.Quantidade);
      if ((typeof row.Qtd === 'number' && row.Qtd < 0) || (typeof row.Quantidade === 'number' && row.Quantidade < 0)) {
        result.summary.negativeStockFixed++;
      }

      // Buscar produto existente
      const existingProduct = await db
        .select()
        .from(products)
        .where(eq(products.code, normalized.code))
        .limit(1);

      if (existingProduct.length > 0) {
        // Atualizar produto existente
        await db
          .update(products)
          .set({
            barcode: normalized.barcode,
            description: normalized.description,
            size: normalized.size,
            color: normalized.color,
            quantity: normalized.quantity,
            unitPrice: normalized.unitPrice.toString(),
            costPrice: normalized.costPrice.toString(),
            salePrice: normalized.salePrice.toString(),
            supplier: normalized.supplier,
            category: normalized.category,
            status: normalized.status as any,
            brand: normalized.brand,
            lastRestockDate: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(products.code, normalized.code));

        result.productsUpdated++;
      } else {
        // Criar novo produto
        await db.insert(products).values({
          code: normalized.code,
          barcode: normalized.barcode,
          description: normalized.description,
          size: normalized.size,
          color: normalized.color,
          quantity: normalized.quantity,
          unitPrice: normalized.unitPrice.toString(),
          costPrice: normalized.costPrice.toString(),
          salePrice: normalized.salePrice.toString(),
          supplier: normalized.supplier,
          category: normalized.category,
          status: normalized.status as any,
          brand: normalized.brand,
          lastRestockDate: new Date(),
        });

        result.productsCreated++;
      }

      // Atualizar resumo
      result.summary.totalProducts++;
      result.summary.totalValue +=
        normalized.quantity * (normalized.salePrice || normalized.unitPrice);
    } catch (err) {
      result.errors.push({
        row: i + 2,
        error: String(err instanceof Error ? err.message : err),
      });
    }
  }

  return result;
}
