/**
 * Importador de Vendas
 * Processa arquivo de vendas em formato Excel
 * Suporta múltiplos formatos: seu arquivo atual, template padrão, etc.
 */

import { getCustomerByPhone, createCustomer } from "../db";
import { processPurchase } from "../business";
import { nanoid } from "nanoid";


export interface SalesImportRow {
  CÓDIGO?: number | string;
  "NºPEDIDO"?: number | string;
  NOME?: string;
  CELULAR?: string;
  VALOR?: number | string;
  "VALOR PAGO"?: number | string;
  "DATA PAGO"?: string | Date;
  EMISSÃO?: string | Date;
  ENDERECO?: string;
  TELEFONE?: string;
  // Template padrão
  "Telefone Cliente"?: string;
  "Data Venda"?: string | Date;
  Produto?: string;
  Quantidade?: number;
  "Valor Unitário"?: number;
  "Valor Total"?: number;
  [key: string]: any;
}

export interface SalesImportResult {
  customersCreated: number;
  salesProcessed: number;
  errors: Array<{ row: number; error: string }>;
  summary: {
    totalValue: number;
    totalPaid: number;
    uniqueCustomers: number;
  };
}

/**
 * Normaliza número de telefone
 * Remove caracteres especiais e valida
 */
function normalizePhone(phone: string | undefined): string | null {
  if (!phone) return null;
  const cleaned = String(phone).replace(/\D/g, "");
  if (cleaned.length < 10) return null;
  // Retorna apenas os últimos 11 dígitos (formato brasileiro)
  return cleaned.slice(-11);
}

/**
 * Extrai valor numérico
 */
function parseValue(value: any): number {
  if (typeof value === "number") return value;
  if (typeof value === "string") {
    const parsed = parseFloat(value.replace(",", "."));
    return isNaN(parsed) ? 0 : parsed;
  }
  return 0;
}

/**
 * Converte data para timestamp
 */
function parseDate(date: any): number | null {
  if (!date) return null;
  try {
    const d = new Date(date);
    if (isNaN(d.getTime())) return null;
    return d.getTime();
  } catch {
    return null;
  }
}

/**
 * Detecta formato da linha de vendas
 */
function detectFormat(row: SalesImportRow): "seu_arquivo" | "template" {
  // Seu arquivo tem CÓDIGO, NºPEDIDO, NOME, CELULAR, VALOR, DATA PAGO
  if (row.CÓDIGO !== undefined || row["NºPEDIDO"] !== undefined) {
    return "seu_arquivo";
  }
  // Template padrão tem Telefone Cliente, Data Venda, Produto, Valor Total
  if (row["Telefone Cliente"] !== undefined || row["Data Venda"] !== undefined) {
    return "template";
  }
  return "seu_arquivo"; // Default
}

/**
 * Normaliza linha de vendas para formato interno
 */
function normalizeSalesRow(row: SalesImportRow, format: "seu_arquivo" | "template") {
  if (format === "seu_arquivo") {
    return {
      customerCode: row.CÓDIGO,
      customerName: row.NOME || "Cliente",
      phone: normalizePhone(row.CELULAR || row.TELEFONE),
      value: parseValue(row.VALOR),
      valuePaid: parseValue(row["VALOR PAGO"]),
      datePaid: parseDate(row["DATA PAGO"] || row.EMISSÃO),
      orderId: String(row["NºPEDIDO"] || nanoid()),
      address: row.ENDERECO,
    };
  } else {
    // Template padrão
    return {
      customerCode: undefined,
      customerName: "Cliente",
      phone: normalizePhone(row["Telefone Cliente"]),
      value: parseValue(row["Valor Total"]),
      valuePaid: parseValue(row["Valor Total"]),
      datePaid: parseDate(row["Data Venda"]),
      orderId: nanoid(),
      address: undefined,
    };
  }
}

/**
 * Importa vendas do arquivo
 */
export async function importSalesData(
  rows: SalesImportRow[]
): Promise<SalesImportResult> {
  const result: SalesImportResult = {
    customersCreated: 0,
    salesProcessed: 0,
    errors: [],
    summary: {
      totalValue: 0,
      totalPaid: 0,
      uniqueCustomers: 0,
    },
  };

  // Rastrear clientes únicos processados
  const processedPhones = new Set<string>();
  const processedOrders = new Set<string>();

  for (let i = 0; i < rows.length; i++) {
    try {
      const row = rows[i];
      if (!row || Object.keys(row).length === 0) continue;

      // Detectar formato
      const format = detectFormat(row);

      // Normalizar dados
      const normalized = normalizeSalesRow(row, format);

      // Validar dados essenciais
      if (!normalized.phone) {
        result.errors.push({
          row: i + 2, // +2 porque começa em 1 e tem header
          error: "Telefone inválido ou não preenchido",
        });
        continue;
      }

      if (normalized.value <= 0) {
        result.errors.push({
          row: i + 2,
          error: "Valor da venda deve ser maior que zero",
        });
        continue;
      }

      // Evitar duplicatas de pedidos
      if (processedOrders.has(normalized.orderId)) {
        continue;
      }
      processedOrders.add(normalized.orderId);

      // Buscar ou criar cliente
      let customer = await getCustomerByPhone(normalized.phone);

      if (!customer) {
        // Criar novo cliente
        const newCustomer = await createCustomer({
          name: normalized.customerName,
          phone: normalized.phone,
          email: undefined,
          birthDate: undefined,
          status: "active",
          tier: "bronze",
          totalSpent: "0",
        });

        customer = await getCustomerByPhone(normalized.phone);
        if (customer && !processedPhones.has(normalized.phone)) {
          result.customersCreated++;
          processedPhones.add(normalized.phone);
        }
      } else if (!processedPhones.has(normalized.phone)) {
        processedPhones.add(normalized.phone);
      }

      // Processar compra
      if (customer) {
        await processPurchase(
          customer.id,
          normalized.value,
          normalized.orderId,
          1 // sem multiplicador de campanha
        );
        result.salesProcessed++;

        // Atualizar resumo
        result.summary.totalValue += normalized.value;
        result.summary.totalPaid += normalized.valuePaid || normalized.value;
      }
    } catch (err) {
      result.errors.push({
        row: i + 2,
        error: String(err instanceof Error ? err.message : err),
      });
    }
  }

  result.summary.uniqueCustomers = processedPhones.size;

  return result;
}
