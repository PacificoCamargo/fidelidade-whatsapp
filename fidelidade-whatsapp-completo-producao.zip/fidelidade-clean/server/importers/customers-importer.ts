/**
 * Importador de Cadastro de Clientes
 * Processa arquivo de cadastro em formato Excel
 * Valida CPF/CNPJ, normaliza dados de contato, e enriquece informações
 */

import { getDb } from "../db";
import { customers } from "../../drizzle/schema";
import { eq } from "drizzle-orm";
import { validateCPF, validateCNPJ, formatCPF, formatCNPJ, normalizePhone } from "../utils/document-validator";

export interface CustomerImportRow {
  CÓDIGO?: number | string;
  NOME?: string;
  ENDERECO?: string;
  NUMERO?: number | string;
  BAIRRO?: string;
  CIDADE?: string;
  CPF?: string;
  CNPJ?: string;
  SEXO?: string;
  "ESTADO CIVIL"?: string;
  PESSOA?: string;
  STATUS?: string;
  "SITUAÇÃO SPC"?: string;
  TELEFONE?: string;
  CELULAR?: string;
  [key: string]: any;
}

export interface CustomerImportResult {
  customersCreated: number;
  customersUpdated: number;
  customersSkipped: number;
  errors: Array<{ row: number; error: string }>;
  summary: {
    totalProcessed: number;
    validCPF: number;
    validCNPJ: number;
    withPhone: number;
  };
}

/**
 * Normaliza nome do cliente
 */
function normalizeName(name: any): string | null {
  if (!name) return null;
  const normalized = String(name).trim();
  if (normalized.length === 0 || normalized.toUpperCase() === "CONSUMIDOR") return null;
  return normalized.substring(0, 255);
}

/**
 * Normaliza CPF
 */
function normalizeCPF(cpf: any): string | null {
  if (!cpf) return null;
  const cleaned = String(cpf).replace(/\D/g, "");
  if (!validateCPF(cleaned)) return null;
  return formatCPF(cleaned);
}

/**
 * Normaliza CNPJ
 */
function normalizeCNPJ(cnpj: any): string | null {
  if (!cnpj) return null;
  const cleaned = String(cnpj).replace(/\D/g, "");
  if (!validateCNPJ(cleaned)) return null;
  return formatCNPJ(cleaned);
}

/**
 * Normaliza status
 */
function normalizeStatus(status: any): "active" | "inactive" {
  if (!status) return "active";
  const normalized = String(status).toUpperCase();
  return normalized === "INATIVO" ? "inactive" : "active";
}

/**
 * Normaliza linha de cadastro de cliente
 */
function normalizeCustomerRow(row: CustomerImportRow) {
  const name = normalizeName(row.NOME);
  if (!name) {
    return null;
  }

  // Prioriza celular, depois telefone
  let phone = normalizePhone(row.CELULAR);
  let secondaryPhone = null;

  if (!phone) {
    phone = normalizePhone(row.TELEFONE);
  } else {
    secondaryPhone = normalizePhone(row.TELEFONE);
  }

  // Se não tem celular nem telefone, não pode importar
  if (!phone) {
    return null;
  }

  return {
    name,
    phone,
    secondaryPhone,
    cpf: normalizeCPF(row.CPF),
    cnpj: normalizeCNPJ(row.CNPJ),
    gender: row.SEXO ? String(row.SEXO).trim() : undefined,
    maritalStatus: row["ESTADO CIVIL"] ? String(row["ESTADO CIVIL"]).trim() : undefined,
    personType: row.PESSOA ? String(row.PESSOA).trim() : undefined,
    address: row.ENDERECO ? String(row.ENDERECO).trim() : undefined,
    addressNumber: row.NUMERO ? String(row.NUMERO).trim() : undefined,
    neighborhood: row.BAIRRO ? String(row.BAIRRO).trim() : undefined,
    city: row.CIDADE ? String(row.CIDADE).trim() : undefined,
    status: normalizeStatus(row.STATUS),
  };
}

/**
 * Importa cadastro de clientes do arquivo
 */
export async function importCustomersData(rows: CustomerImportRow[]): Promise<CustomerImportResult> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database connection failed");
  }

  const result: CustomerImportResult = {
    customersCreated: 0,
    customersUpdated: 0,
    customersSkipped: 0,
    errors: [],
    summary: {
      totalProcessed: 0,
      validCPF: 0,
      validCNPJ: 0,
      withPhone: 0,
    },
  };

  for (let i = 0; i < rows.length; i++) {
    try {
      const row = rows[i];
      if (!row || Object.keys(row).length === 0) continue;

      // Normalizar dados
      const normalized = normalizeCustomerRow(row);
      if (!normalized) {
        result.customersSkipped++;
        continue;
      }

      result.summary.totalProcessed++;
      if (normalized.cpf) result.summary.validCPF++;
      if (normalized.cnpj) result.summary.validCNPJ++;
      if (normalized.phone) result.summary.withPhone++;

      // Buscar cliente existente por telefone
      const existingCustomer = await db
        .select()
        .from(customers)
        .where(eq(customers.phone, normalized.phone))
        .limit(1);

      if (existingCustomer.length > 0) {
        // Atualizar cliente existente
        await db
          .update(customers)
          .set({
            name: normalized.name,
            cpf: normalized.cpf,
            cnpj: normalized.cnpj,
            gender: normalized.gender,
            maritalStatus: normalized.maritalStatus,
            personType: normalized.personType,
            address: normalized.address,
            addressNumber: normalized.addressNumber,
            neighborhood: normalized.neighborhood,
            city: normalized.city,
            secondaryPhone: normalized.secondaryPhone,
            status: normalized.status,
            updatedAt: new Date(),
          })
          .where(eq(customers.phone, normalized.phone));

        result.customersUpdated++;
      } else {
        // Criar novo cliente
        await db.insert(customers).values({
          name: normalized.name,
          phone: normalized.phone,
          cpf: normalized.cpf,
          cnpj: normalized.cnpj,
          gender: normalized.gender,
          maritalStatus: normalized.maritalStatus,
          personType: normalized.personType,
          address: normalized.address,
          addressNumber: normalized.addressNumber,
          neighborhood: normalized.neighborhood,
          city: normalized.city,
          secondaryPhone: normalized.secondaryPhone,
          status: normalized.status,
          tier: "bronze",
          totalSpent: "0",
        });

        result.customersCreated++;
      }
    } catch (err) {
      result.errors.push({
        row: i + 2,
        error: String(err instanceof Error ? err.message : err),
      });
    }
  }

  return result;
}
