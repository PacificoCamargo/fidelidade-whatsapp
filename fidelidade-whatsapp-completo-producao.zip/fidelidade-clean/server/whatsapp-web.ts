import { createRequire } from 'module';
import path from 'path';
import * as qrcode from 'qrcode';

const require = createRequire(import.meta.url);
const { Client, LocalAuth } = require('whatsapp-web.js');

interface WhatsAppSession {
  qrCode: string | null;
  isConnected: boolean;
  phoneNumber: string | null;
  client: any;
  isInitializing: boolean;
}

let whatsappSession: WhatsAppSession = {
  qrCode: null,
  isConnected: false,
  phoneNumber: null,
  client: null,
  isInitializing: false,
};

const AUTH_DIR = path.join(process.cwd(), '.whatsapp-web-auth');

export async function initializeWhatsApp() {
  try {
    // Evitar múltiplas inicializações simultâneas
    if (whatsappSession.isInitializing) {
      console.log('[WhatsApp Web] Já está inicializando...');
      return whatsappSession.client;
    }

    whatsappSession.isInitializing = true;
    console.log('[WhatsApp Web] Iniciando cliente...');

    // Criar cliente com autenticação local
    const client = new Client({
      authStrategy: new LocalAuth({
        clientId: 'fidelidade-whatsapp',
      }),
      puppeteer: {
        headless: true,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-gpu',
        ],
      },
    });

    // Evento: QR Code gerado
    client.on('qr', async (qr: string) => {
      try {
        console.log('[WhatsApp Web] Gerando QR code...');
        const qrDataUrl = await qrcode.toDataURL(qr);
        whatsappSession.qrCode = qrDataUrl;
        console.log('[WhatsApp Web] ✓ QR Code gerado com sucesso');
      } catch (err) {
        console.error('[WhatsApp Web] Erro ao gerar QR code:', err);
      }
    });

    // Evento: Cliente pronto
    client.on('ready', () => {
      whatsappSession.isConnected = true;
      whatsappSession.qrCode = null;
      whatsappSession.isInitializing = false;
      console.log('[WhatsApp Web] ✓ Cliente pronto e conectado!');

      // Obter informações do usuário
      try {
        const info = client.info;
        if (info && info.wid) {
          whatsappSession.phoneNumber = info.wid.user;
          console.log('[WhatsApp Web] Número:', whatsappSession.phoneNumber);
        }
      } catch (err) {
        console.error('[WhatsApp Web] Erro ao obter número:', err);
      }
    });

    // Evento: Cliente autenticado
    client.on('authenticated', () => {
      console.log('[WhatsApp Web] ✓ Autenticado com sucesso!');
      whatsappSession.qrCode = null;
    });

    // Evento: Desconectado
    client.on('disconnected', (reason: string) => {
      console.log('[WhatsApp Web] Desconectado:', reason);
      whatsappSession.isConnected = false;
      whatsappSession.qrCode = null;
      whatsappSession.isInitializing = false;
      whatsappSession.client = null;
    });

    // Evento: Mensagem recebida
    client.on('message', (msg: any) => {
      console.log('[WhatsApp Web] Mensagem recebida:', msg.body);
    });

    // Evento: Erro
    client.on('error', (error: Error) => {
      console.error('[WhatsApp Web] Erro:', error);
      whatsappSession.isInitializing = false;
    });

    // Inicializar cliente
    await client.initialize();

    whatsappSession.client = client;
    return client;
  } catch (err) {
    console.error('[WhatsApp Web] Erro ao inicializar:', err);
    whatsappSession.isInitializing = false;
    throw err;
  }
}

export async function sendMessage(phoneNumber: string, message: string) {
  if (!whatsappSession.client || !whatsappSession.isConnected) {
    throw new Error('WhatsApp não está conectado');
  }

  try {
    // Formatar número para formato WhatsApp
    const chatId = phoneNumber.includes('@') ? phoneNumber : `${phoneNumber}@c.us`;

    await whatsappSession.client.sendMessage(chatId, message);
    console.log('[WhatsApp Web] Mensagem enviada para:', phoneNumber);

    return { success: true, message: 'Mensagem enviada com sucesso' };
  } catch (err) {
    console.error('[WhatsApp Web] Erro ao enviar mensagem:', err);
    throw err;
  }
}

export async function sendBulkMessages(
  recipients: Array<{ phone: string; name: string }>,
  message: string,
  delayMs: number = 1000
) {
  if (!whatsappSession.client || !whatsappSession.isConnected) {
    throw new Error('WhatsApp não está conectado');
  }

  const results = [];

  for (const recipient of recipients) {
    try {
      // Formatar número para formato WhatsApp
      const chatId = recipient.phone.includes('@') ? recipient.phone : `${recipient.phone}@c.us`;

      // Personalizar mensagem com nome
      const personalizedMessage = message.replace('{nome}', recipient.name);

      await whatsappSession.client.sendMessage(chatId, personalizedMessage);

      results.push({
        phone: recipient.phone,
        status: 'sent',
        error: null,
      });

      console.log('[WhatsApp Web] Mensagem enviada para:', recipient.phone);

      // Delay entre mensagens para não ser bloqueado
      await new Promise(resolve => setTimeout(resolve, delayMs));
    } catch (err) {
      results.push({
        phone: recipient.phone,
        status: 'error',
        error: (err as Error).message,
      });

      console.error('[WhatsApp Web] Erro ao enviar para:', recipient.phone, err);
    }
  }

  return results;
}

export function getWhatsAppStatus() {
  return {
    isConnected: whatsappSession.isConnected,
    qrCode: whatsappSession.qrCode,
    phoneNumber: whatsappSession.phoneNumber,
    isInitializing: whatsappSession.isInitializing,
  };
}

export function disconnectWhatsApp() {
  if (whatsappSession.client) {
    whatsappSession.client.destroy();
    whatsappSession.isConnected = false;
    whatsappSession.qrCode = null;
    whatsappSession.phoneNumber = null;
    whatsappSession.isInitializing = false;
    whatsappSession.client = null;
    console.log('[WhatsApp Web] Desconectado');
  }
}
