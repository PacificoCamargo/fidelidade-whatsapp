import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, customers, InsertCustomer, wallets, InsertWallet, transactions, InsertTransaction, rewards, InsertReward, redemptions, InsertRedemption, campaigns, InsertCampaign, rulesConfig, InsertRulesConfig, referrals, InsertReferral, salesFrequencyAnalysis, InsertSalesFrequencyAnalysis, aiRecommendations, InsertAIRecommendation, productBehaviorAnalysis, InsertProductBehaviorAnalysis, aiGeneratedCampaigns, InsertAIGeneratedCampaign, products, InsertProduct, stockMovements, InsertStockMovement } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ CUSTOMERS ============

export async function getCustomerByPhone(phone: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(customers).where(eq(customers.phone, phone)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllCustomers(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(customers).limit(limit).offset(offset);
}

export async function createCustomer(data: InsertCustomer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(customers).values(data);
  return result;
}

export async function updateCustomer(id: number, data: Partial<InsertCustomer>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(customers).set(data).where(eq(customers.id, id));
}

// ============ WALLETS ============

export async function getWalletByCustomerId(customerId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(wallets).where(eq(wallets.customerId, customerId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createWallet(customerId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(wallets).values({ customerId });
}

export async function updateWallet(customerId: number, data: Partial<InsertWallet>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(wallets).set(data).where(eq(wallets.customerId, customerId));
}

// ============ TRANSACTIONS ============

export async function createTransaction(data: InsertTransaction) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(transactions).values(data);
}

export async function getTransactionsByCustomerId(customerId: number, limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(transactions).where(eq(transactions.customerId, customerId)).orderBy(desc(transactions.createdAt)).limit(limit).offset(offset);
}

// ============ REWARDS ============

export async function getAllRewards() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(rewards).where(eq(rewards.active, true));
}

export async function createReward(data: InsertReward) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(rewards).values(data);
}

export async function updateReward(id: number, data: Partial<InsertReward>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(rewards).set(data).where(eq(rewards.id, id));
}

// ============ REDEMPTIONS ============

export async function createRedemption(data: InsertRedemption) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(redemptions).values(data);
}

export async function getRedemptionsByCustomerId(customerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(redemptions).where(eq(redemptions.customerId, customerId));
}

export async function updateRedemption(id: number, data: Partial<InsertRedemption>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(redemptions).set(data).where(eq(redemptions.id, id));
}

// ============ CAMPAIGNS ============

export async function getAllCampaigns() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(campaigns).where(eq(campaigns.active, true));
}

export async function createCampaign(data: InsertCampaign) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(campaigns).values(data);
}

export async function updateCampaign(id: number, data: Partial<InsertCampaign>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(campaigns).set(data).where(eq(campaigns.id, id));
}

// ============ RULES CONFIG ============

export async function getRulesConfig() {
  const db = await getDb();
  const defaultConfig = {
    id: 1,
    name: 'Configuração Padrão',
    pointsPerReal: '1',
    cashbackPercentage: '5',
    pointsExpirationDays: 90,
    bronzeCashback: '5',
    prataThreshold: '1500',
    prataCashback: '7',
    ouroThreshold: '3000',
    ouroCashback: '10',
    createdAt: new Date(),
    updatedAt: new Date(),
  };
  
  if (!db) return defaultConfig;
  
  const result = await db.select().from(rulesConfig).limit(1);
  return result.length > 0 ? result[0] : defaultConfig;
}

export async function createRulesConfig(data: InsertRulesConfig) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(rulesConfig).values(data);
}

export async function updateRulesConfig(id: number, data: Partial<InsertRulesConfig>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(rulesConfig).set(data).where(eq(rulesConfig.id, id));
}

// ============ REFERRALS ============

export async function createReferral(data: InsertReferral) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(referrals).values(data);
}

export async function getReferralsByReferrerId(referrerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(referrals).where(eq(referrals.referrerId, referrerId));
}

// ============ AI ANALYTICS ============

export async function getSalesFrequencyAnalysis(customerId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(salesFrequencyAnalysis).where(eq(salesFrequencyAnalysis.customerId, customerId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrUpdateSalesFrequencyAnalysis(data: InsertSalesFrequencyAnalysis) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await getSalesFrequencyAnalysis(data.customerId);
  if (existing) {
    return await db.update(salesFrequencyAnalysis).set(data).where(eq(salesFrequencyAnalysis.customerId, data.customerId));
  }
  return await db.insert(salesFrequencyAnalysis).values(data);
}

export async function getAIRecommendationsByCustomerId(customerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(aiRecommendations).where(eq(aiRecommendations.customerId, customerId)).orderBy(desc(aiRecommendations.createdAt));
}

export async function createAIRecommendation(data: InsertAIRecommendation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(aiRecommendations).values(data);
}

export async function updateAIRecommendation(id: number, data: Partial<InsertAIRecommendation>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(aiRecommendations).set(data).where(eq(aiRecommendations.id, id));
}

export async function getProductBehaviorAnalysis(customerId: number, productCategory: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(productBehaviorAnalysis)
    .where(eq(productBehaviorAnalysis.customerId, customerId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createOrUpdateProductBehaviorAnalysis(data: InsertProductBehaviorAnalysis) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const existing = await getProductBehaviorAnalysis(data.customerId, data.productCategory);
  if (existing) {
    return await db.update(productBehaviorAnalysis).set(data).where(eq(productBehaviorAnalysis.id, existing.id));
  }
  return await db.insert(productBehaviorAnalysis).values(data);
}

export async function getAIGeneratedCampaigns(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(aiGeneratedCampaigns).where(eq(aiGeneratedCampaigns.userId, userId)).orderBy(desc(aiGeneratedCampaigns.createdAt));
}

export async function createAIGeneratedCampaign(data: InsertAIGeneratedCampaign) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(aiGeneratedCampaigns).values(data);
}

export async function updateAIGeneratedCampaign(id: number, data: Partial<InsertAIGeneratedCampaign>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(aiGeneratedCampaigns).set(data).where(eq(aiGeneratedCampaigns.id, id));
}


// ============ PRODUCTS ============

export async function getAllProducts(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(products).limit(limit).offset(offset);
}

export async function getProductByCode(code: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(products).where(eq(products.code, code)).limit(1);
  return result[0] || null;
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result[0] || null;
}

export async function createProduct(data: InsertProduct) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(products).values(data);
  return result;
}

export async function updateProduct(id: number, data: Partial<InsertProduct>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(products).set(data).where(eq(products.id, id));
}

export async function createStockMovement(data: InsertStockMovement) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(stockMovements).values(data);
}

export async function getStockMovements(productId: number, limit = 50, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(stockMovements).where(eq(stockMovements.productId, productId)).limit(limit).offset(offset);
}
