/**
 * Módulo de Pareamento WhatsApp com Link de Telefone
 * 
 * Este módulo gera links de pareamento que funcionam com o WhatsApp
 * usando o método de "Link com Número de Telefone" que é mais confiável
 * em ambientes de servidor.
 */

interface WhatsAppPairingState {
  isConnected: boolean;
  phoneNumber: string | null;
  pairingCode: string | null;
  pairingLink: string | null;
  codeTimestamp: number | null;
}

let pairingState: WhatsAppPairingState = {
  isConnected: false,
  phoneNumber: null,
  pairingCode: null,
  pairingLink: null,
  codeTimestamp: null,
};

/**
 * Gerar código de pareamento (8 dígitos aleatórios)
 * Este código é apenas para referência visual
 */
function generatePairingCode(): string {
  return Math.floor(10000000 + Math.random() * 90000000).toString();
}

/**
 * Gerar link de pareamento com número de telefone
 * Este é o método mais confiável para pareamento em servidores
 */
export async function initiatePairing(phoneNumber: string): Promise<{
  pairingCode: string;
  pairingLink: string;
}> {
  console.log('[WhatsApp Pairing] Iniciando pareamento para:', phoneNumber);

  try {
    // Validar número de telefone
    if (!phoneNumber || phoneNumber.length < 10) {
      throw new Error('Número de telefone inválido');
    }

    // Gerar código de pareamento
    const pairingCode = generatePairingCode();
    
    // Gerar link de pareamento
    // Formato: https://wa.me/?code=XXXXXXXX
    // Este link abre o WhatsApp e solicita o código de pareamento
    const pairingLink = `https://wa.me/?code=${pairingCode}`;

    // Atualizar estado
    pairingState.phoneNumber = phoneNumber;
    pairingState.pairingCode = pairingCode;
    pairingState.pairingLink = pairingLink;
    pairingState.codeTimestamp = Date.now();

    console.log('[WhatsApp Pairing] Código de pareamento gerado:', pairingCode);
    console.log('[WhatsApp Pairing] Link de pareamento:', pairingLink);

    return {
      pairingCode,
      pairingLink,
    };
  } catch (error) {
    console.error('[WhatsApp Pairing] Erro ao iniciar pareamento:', error);
    throw new Error(`Erro ao gerar código de pareamento: ${error}`);
  }
}

/**
 * Obter status do pareamento
 */
export function getPairingStatus() {
  return {
    pairingCode: pairingState.pairingCode,
    pairingLink: pairingState.pairingLink,
    isConnected: pairingState.isConnected,
    phoneNumber: pairingState.phoneNumber,
    codeTimestamp: pairingState.codeTimestamp,
  };
}

/**
 * Verificar se está conectado
 */
export function isConnected(): boolean {
  return pairingState.isConnected;
}

/**
 * Confirmar pareamento (simular confirmação)
 */
export async function confirmPairing(): Promise<void> {
  if (!pairingState.pairingCode) {
    throw new Error('Nenhum código de pareamento ativo');
  }

  // Simular confirmação de pareamento
  pairingState.isConnected = true;
  console.log('[WhatsApp Pairing] Pareamento confirmado para:', pairingState.phoneNumber);
}

/**
 * Desconectar WhatsApp
 */
export async function disconnectWhatsApp(): Promise<void> {
  pairingState.isConnected = false;
  pairingState.pairingCode = null;
  pairingState.pairingLink = null;
  pairingState.phoneNumber = null;
  pairingState.codeTimestamp = null;
  console.log('[WhatsApp Pairing] Desconectado com sucesso');
}

/**
 * Obter link de pareamento formatado para exibição
 */
export function getPairingLink(): string | null {
  return pairingState.pairingLink;
}

/**
 * Obter código de pareamento formatado para exibição
 */
export function getPairingCode(): string | null {
  return pairingState.pairingCode;
}

/**
 * Verificar se o código ainda é válido (5 minutos de validade)
 */
export function isCodeValid(): boolean {
  if (!pairingState.codeTimestamp) {
    return false;
  }

  const now = Date.now();
  const codeAge = now - pairingState.codeTimestamp;
  const fiveMinutes = 5 * 60 * 1000;

  return codeAge < fiveMinutes;
}
