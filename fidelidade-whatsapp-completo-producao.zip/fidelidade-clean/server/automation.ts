import { getDb } from "./db";
// import { sendWhatsAppMessage } from "./whatsapp"; // Removido - usar integração com WhatsApp Business API
import {
  automationTriggers,
  automationLogs,
  customers,
  wallets,
  whatsappSessions,
  whatsappMessages,
} from "../drizzle/schema";
import { eq, and, lte, gte } from "drizzle-orm";
import { addDays, startOfDay, endOfDay } from "date-fns";

interface TriggerConditions {
  minPoints?: number;
  maxPoints?: number;
  minCashback?: number;
  daysUntilExpiry?: number;
  tier?: string[];
}

/**
 * Processa triggers de automação
 */
export async function processTriggers() {
  try {
    const db = await getDb();
    if (!db) {
      console.error("[Automation] Database not available");
      return;
    }

    // Obter todos os triggers ativos
    const triggers = await db
      .select()
      .from(automationTriggers)
      .where(eq(automationTriggers.isActive, true));

    for (const trigger of triggers) {
      try {
        await executeTrigger(db, trigger);
      } catch (error) {
        console.error(`[Automation] Erro ao executar trigger ${trigger.id}:`, error);
      }
    }
  } catch (error) {
    console.error("[Automation] Erro ao processar triggers:", error);
  }
}

/**
 * Executa um trigger específico
 */
async function executeTrigger(db: any, trigger: any) {
  const now = new Date();

  // Verificar se deve executar (próxima execução)
  if (trigger.nextExecution && trigger.nextExecution > now) {
    return;
  }

  const conditions = trigger.conditions ? JSON.parse(trigger.conditions) : {};

  switch (trigger.triggerType) {
    case "points_accumulated":
      await handlePointsAccumulated(db, trigger, conditions);
      break;
    case "cashback_available":
      await handleCashbackAvailable(db, trigger, conditions);
      break;
    case "points_expiring":
      await handlePointsExpiring(db, trigger, conditions);
      break;
    case "birthday":
      await handleBirthday(db, trigger, conditions);
      break;
    case "tier_upgrade":
      await handleTierUpgrade(db, trigger, conditions);
      break;
    case "purchase_milestone":
      await handlePurchaseMilestone(db, trigger, conditions);
      break;
  }

  // Atualizar trigger
  await db
    .update(automationTriggers)
    .set({
      lastExecuted: now,
      nextExecution: addDays(now, 1), // Próxima execução em 1 dia
      executionCount: (trigger.executionCount || 0) + 1,
    })
    .where(eq(automationTriggers.id, trigger.id));
}

/**
 * Notificação de pontos acumulados
 */
async function handlePointsAccumulated(db: any, trigger: any, conditions: TriggerConditions) {
  const customers_list = await db.select().from(customers).where(eq(customers.status, "active"));

  for (const customer of customers_list) {
    try {
      const wallet = await db
        .select()
        .from(wallets)
        .where(eq(wallets.customerId, customer.id))
        .limit(1);

      if (!wallet.length) continue;

      const points = wallet[0].points;

      // Verificar condições
      if (conditions.minPoints && points < conditions.minPoints) continue;
      if (conditions.maxPoints && points > conditions.maxPoints) continue;

      // Preparar mensagem
      const message = trigger.messageTemplate
        .replace("{name}", customer.name)
        .replace("{points}", points.toString())
        .replace("{tier}", customer.tier);

      // Enviar mensagem
      const session = await db
        .select()
        .from(whatsappSessions)
        .where(eq(whatsappSessions.userId, trigger.userId))
        .limit(1);

      if (session.length > 0) {
        // const success = await sendWhatsAppMessage(trigger.userId, customer.phone, message);
        const success = false; // Placeholder

        // Registrar log
        await db.insert(automationLogs).values({
          triggerId: trigger.id,
          customerId: customer.id,
          status: success ? "sent" : "failed",
          executedAt: new Date(),
        });

        // Registrar mensagem
        if (success) {
          await db.insert(whatsappMessages).values({
            sessionId: session[0].id,
            customerId: customer.id,
            phoneNumber: customer.phone,
            message,
            messageType: "text",
            status: "sent",
            sentAt: new Date(),
          });
        }
      }
    } catch (error) {
      console.error(`[Automation] Erro ao processar cliente ${customer.id}:`, error);
    }
  }
}

/**
 * Notificação de cashback disponível
 */
async function handleCashbackAvailable(db: any, trigger: any, conditions: TriggerConditions) {
  const customers_list = await db.select().from(customers).where(eq(customers.status, "active"));

  for (const customer of customers_list) {
    try {
      const wallet = await db
        .select()
        .from(wallets)
        .where(eq(wallets.customerId, customer.id))
        .limit(1);

      if (!wallet.length) continue;

      const cashback = wallet[0].cashback;

      // Verificar condições
      if (conditions.minCashback && cashback < conditions.minCashback) continue;

      // Preparar mensagem
      const message = trigger.messageTemplate
        .replace("{name}", customer.name)
        .replace("{cashback}", cashback.toString())
        .replace("{tier}", customer.tier);

      // Enviar mensagem
      const session = await db
        .select()
        .from(whatsappSessions)
        .where(eq(whatsappSessions.userId, trigger.userId))
        .limit(1);

      if (session.length > 0) {
        // const success = await sendWhatsAppMessage(trigger.userId, customer.phone, message);
        const success = false; // Placeholder

        await db.insert(automationLogs).values({
          triggerId: trigger.id,
          customerId: customer.id,
          status: success ? "sent" : "failed",
          executedAt: new Date(),
        });

        if (success) {
          await db.insert(whatsappMessages).values({
            sessionId: session[0].id,
            customerId: customer.id,
            phoneNumber: customer.phone,
            message,
            messageType: "text",
            status: "sent",
            sentAt: new Date(),
          });
        }
      }
    } catch (error) {
      console.error(`[Automation] Erro ao processar cliente ${customer.id}:`, error);
    }
  }
}

/**
 * Alerta de expiração de pontos
 */
async function handlePointsExpiring(db: any, trigger: any, conditions: TriggerConditions) {
  const daysUntilExpiry = conditions.daysUntilExpiry || 7;
  const expiryDate = addDays(new Date(), daysUntilExpiry);

  const customers_list = await db.select().from(customers).where(eq(customers.status, "active"));

  for (const customer of customers_list) {
    try {
      const wallet = await db
        .select()
        .from(wallets)
        .where(eq(wallets.customerId, customer.id))
        .limit(1);

      if (!wallet.length || wallet[0].points === 0) continue;

      // Verificar se pontos expiram em breve
      if (!wallet[0].pointsExpiryDate || wallet[0].pointsExpiryDate > expiryDate) continue;

      const daysRemaining = Math.ceil(
        (wallet[0].pointsExpiryDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)
      );

      // Preparar mensagem
      const message = trigger.messageTemplate
        .replace("{name}", customer.name)
        .replace("{points}", wallet[0].points.toString())
        .replace("{daysRemaining}", daysRemaining.toString());

      // Enviar mensagem
      const session = await db
        .select()
        .from(whatsappSessions)
        .where(eq(whatsappSessions.userId, trigger.userId))
        .limit(1);

      if (session.length > 0) {
        // const success = await sendWhatsAppMessage(trigger.userId, customer.phone, message);
        const success = false; // Placeholder

        await db.insert(automationLogs).values({
          triggerId: trigger.id,
          customerId: customer.id,
          status: success ? "sent" : "failed",
          executedAt: new Date(),
        });

        if (success) {
          await db.insert(whatsappMessages).values({
            sessionId: session[0].id,
            customerId: customer.id,
            phoneNumber: customer.phone,
            message,
            messageType: "text",
            status: "sent",
            sentAt: new Date(),
          });
        }
      }
    } catch (error) {
      console.error(`[Automation] Erro ao processar cliente ${customer.id}:`, error);
    }
  }
}

/**
 * Bônus de aniversário
 */
async function handleBirthday(db: any, trigger: any, conditions: TriggerConditions) {
  const today = new Date();
  const month = today.getMonth() + 1;
  const day = today.getDate();

  // Buscar clientes que fazem aniversário hoje
  const customers_list = await db
    .select()
    .from(customers)
    .where(eq(customers.status, "active"));

  const birthdayCustomers = customers_list.filter((c: any) => {
    if (!c.birthDate) return false;
    const birthMonth = c.birthDate.getMonth() + 1;
    const birthDay = c.birthDate.getDate();
    return birthMonth === month && birthDay === day;
  });

  for (const customer of birthdayCustomers) {
    try {
      // Preparar mensagem
      const message = trigger.messageTemplate.replace("{name}", customer.name);

      // Enviar mensagem
      const session = await db
        .select()
        .from(whatsappSessions)
        .where(eq(whatsappSessions.userId, trigger.userId))
        .limit(1);

      if (session.length > 0) {
        // const success = await sendWhatsAppMessage(trigger.userId, customer.phone, message);
        const success = false; // Placeholder

        await db.insert(automationLogs).values({
          triggerId: trigger.id,
          customerId: customer.id,
          status: success ? "sent" : "failed",
          executedAt: new Date(),
        });

        if (success) {
          await db.insert(whatsappMessages).values({
            sessionId: session[0].id,
            customerId: customer.id,
            phoneNumber: customer.phone,
            message,
            messageType: "text",
            status: "sent",
            sentAt: new Date(),
          });
        }
      }
    } catch (error) {
      console.error(`[Automation] Erro ao processar cliente ${customer.id}:`, error);
    }
  }
}

/**
 * Upgrade de tier
 */
async function handleTierUpgrade(db: any, trigger: any, conditions: TriggerConditions) {
  const customers_list = await db.select().from(customers).where(eq(customers.status, "active"));

  for (const customer of customers_list) {
    try {
      // Verificar se tier está na lista de condições
      if (conditions.tier && !conditions.tier.includes(customer.tier)) continue;

      // Preparar mensagem
      const message = trigger.messageTemplate
        .replace("{name}", customer.name)
        .replace("{tier}", customer.tier);

      // Enviar mensagem
      const session = await db
        .select()
        .from(whatsappSessions)
        .where(eq(whatsappSessions.userId, trigger.userId))
        .limit(1);

      if (session.length > 0) {
        // const success = await sendWhatsAppMessage(trigger.userId, customer.phone, message);
        const success = false; // Placeholder

        await db.insert(automationLogs).values({
          triggerId: trigger.id,
          customerId: customer.id,
          status: success ? "sent" : "failed",
          executedAt: new Date(),
        });

        if (success) {
          await db.insert(whatsappMessages).values({
            sessionId: session[0].id,
            customerId: customer.id,
            phoneNumber: customer.phone,
            message,
            messageType: "text",
            status: "sent",
            sentAt: new Date(),
          });
        }
      }
    } catch (error) {
      console.error(`[Automation] Erro ao processar cliente ${customer.id}:`, error);
    }
  }
}

/**
 * Marco de compra
 */
async function handlePurchaseMilestone(db: any, trigger: any, conditions: TriggerConditions) {
  const customers_list = await db.select().from(customers).where(eq(customers.status, "active"));

  for (const customer of customers_list) {
    try {
      // Verificar se atingiu o marco de compra
      if (conditions.minPoints && customer.totalSpent < conditions.minPoints) continue;

      // Preparar mensagem
      const message = trigger.messageTemplate
        .replace("{name}", customer.name)
        .replace("{totalSpent}", customer.totalSpent.toString());

      // Enviar mensagem
      const session = await db
        .select()
        .from(whatsappSessions)
        .where(eq(whatsappSessions.userId, trigger.userId))
        .limit(1);

      if (session.length > 0) {
        // const success = await sendWhatsAppMessage(trigger.userId, customer.phone, message);
        const success = false; // Placeholder

        await db.insert(automationLogs).values({
          triggerId: trigger.id,
          customerId: customer.id,
          status: success ? "sent" : "failed",
          executedAt: new Date(),
        });

        if (success) {
          await db.insert(whatsappMessages).values({
            sessionId: session[0].id,
            customerId: customer.id,
            phoneNumber: customer.phone,
            message,
            messageType: "text",
            status: "sent",
            sentAt: new Date(),
          });
        }
      }
    } catch (error) {
      console.error(`[Automation] Erro ao processar cliente ${customer.id}:`, error);
    }
  }
}
