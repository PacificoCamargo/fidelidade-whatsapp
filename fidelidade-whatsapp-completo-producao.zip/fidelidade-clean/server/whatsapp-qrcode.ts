/**
 * Módulo de Geração de QR Code WhatsApp - Stateless e Serverless-Compatible
 * 
 * Gera QR Code imediatamente no request HTTP sem manter estado persistente
 * Retorna o QR como base64 na resposta
 * Compatível com ambientes serverless
 */

import QRCode from 'qrcode';

interface QRCodeResponse {
  qrCodeBase64: string;
  qrCodeDataUrl: string;
  expiresIn: number; // segundos
  timestamp: number;
}

/**
 * Gerar QR Code para pareamento WhatsApp
 * Executa de forma síncrona e retorna o resultado imediatamente
 * 
 * @param phoneNumber - Número de telefone no formato internacional (ex: 5511999999999)
 * @returns QR Code em base64 e data URL
 */
export async function generateWhatsAppQRCode(phoneNumber: string): Promise<QRCodeResponse> {
  console.log('[WhatsApp QR] Gerando QR Code para:', phoneNumber);

  try {
    // Validar número de telefone
    if (!phoneNumber || phoneNumber.length < 10) {
      throw new Error('Número de telefone inválido. Use o formato: 55XXXXXXXXXXX');
    }

    // Gerar dados do QR Code
    // Formato: https://wa.me/{phoneNumber}
    // Este é o padrão oficial do WhatsApp para links de contato
    const qrData = `https://wa.me/${phoneNumber}`;

    console.log('[WhatsApp QR] Dados do QR Code:', qrData);

    // Gerar QR Code como data URL (PNG)
    const qrCodeDataUrl = await QRCode.toDataURL(qrData, {
      errorCorrectionLevel: 'H' as any, // Nível alto de correção de erro
      width: 300,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
    });

    // Extrair base64 da data URL (remover prefixo "data:image/png;base64,")
    const qrCodeBase64 = qrCodeDataUrl.split(',')[1];

    // QR Code válido por 10 minutos
    const expiresIn = 10 * 60;

    console.log('[WhatsApp QR] QR Code gerado com sucesso');

    return {
      qrCodeBase64,
      qrCodeDataUrl,
      expiresIn,
      timestamp: Date.now(),
    };
  } catch (error) {
    console.error('[WhatsApp QR] Erro ao gerar QR Code:', error);
    throw new Error(`Erro ao gerar QR Code: ${error instanceof Error ? error.message : String(error)}`);
  }
}

/**
 * Gerar QR Code com dados customizados
 * Útil para incluir informações adicionais no QR Code
 * 
 * @param data - Dados a serem codificados no QR Code
 * @returns QR Code em base64
 */
export async function generateCustomQRCode(data: string): Promise<QRCodeResponse> {
  console.log('[WhatsApp QR] Gerando QR Code customizado');

  try {
    if (!data || data.trim().length === 0) {
      throw new Error('Dados do QR Code não podem estar vazios');
    }

    // Gerar QR Code como data URL
    const qrCodeDataUrl = await QRCode.toDataURL(data, {
      errorCorrectionLevel: 'H' as any,
      width: 300,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
    });

    // Extrair base64
    const qrCodeBase64 = qrCodeDataUrl.split(',')[1];

    // QR Code válido por 10 minutos
    const expiresIn = 10 * 60;

    console.log('[WhatsApp QR] QR Code customizado gerado com sucesso');

    return {
      qrCodeBase64,
      qrCodeDataUrl,
      expiresIn,
      timestamp: Date.now(),
    };
  } catch (error) {
    console.error('[WhatsApp QR] Erro ao gerar QR Code customizado:', error);
    throw new Error(`Erro ao gerar QR Code: ${error instanceof Error ? error.message : String(error)}`);
  }
}

/**
 * Validar se um QR Code ainda é válido
 * 
 * @param timestamp - Timestamp de quando o QR Code foi gerado
 * @param expiresIn - Tempo de validade em segundos
 * @returns true se ainda é válido, false caso contrário
 */
export function isQRCodeValid(timestamp: number, expiresIn: number): boolean {
  const now = Date.now();
  const ageInSeconds = (now - timestamp) / 1000;
  return ageInSeconds < expiresIn;
}

/**
 * Converter base64 para Buffer (útil para salvar em arquivo ou enviar como anexo)
 * 
 * @param base64 - String base64
 * @returns Buffer
 */
export function base64ToBuffer(base64: string): Buffer {
  return Buffer.from(base64, 'base64');
}

/**
 * Gerar QR Code como arquivo PNG (para salvar em S3 ou similar)
 * 
 * @param phoneNumber - Número de telefone
 * @returns Buffer PNG
 */
export async function generateWhatsAppQRCodeAsBuffer(phoneNumber: string): Promise<Buffer> {
  console.log('[WhatsApp QR] Gerando QR Code como buffer para:', phoneNumber);

  try {
    if (!phoneNumber || phoneNumber.length < 10) {
      throw new Error('Número de telefone inválido');
    }

    const qrData = `https://wa.me/${phoneNumber}`;

    // Gerar QR Code como PNG buffer
    const pngBuffer: any = await QRCode.toBuffer(qrData, {
      errorCorrectionLevel: 'H' as any,
      width: 300,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
    } as any);

    console.log('[WhatsApp QR] QR Code buffer gerado com sucesso');

    return pngBuffer as Buffer;
  } catch (error) {
    console.error('[WhatsApp QR] Erro ao gerar QR Code buffer:', error);
    throw new Error(`Erro ao gerar QR Code: ${error instanceof Error ? error.message : String(error)}`);
  }
}
