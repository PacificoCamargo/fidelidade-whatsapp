import { makeWASocket, DisconnectReason, useMultiFileAuthState, proto } from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import * as qrcode from 'qrcode';
import * as fs from 'fs';
import * as path from 'path';

interface WhatsAppSession {
  qrCode: string | null;
  isConnected: boolean;
  phoneNumber: string | null;
  socket: any;
  isInitializing: boolean;
}

let whatsappSession: WhatsAppSession = {
  qrCode: null,
  isConnected: false,
  phoneNumber: null,
  socket: null,
  isInitializing: false,
};

const AUTH_DIR = path.join(process.cwd(), '.whatsapp-auth');

// Garantir que o diretório existe
if (!fs.existsSync(AUTH_DIR)) {
  fs.mkdirSync(AUTH_DIR, { recursive: true });
}

export async function initializeWhatsApp() {
  try {
    // Evitar múltiplas inicializações simultâneas
    if (whatsappSession.isInitializing) {
      console.log('[WhatsApp] Já está inicializando...');
      return whatsappSession.socket;
    }

    whatsappSession.isInitializing = true;
    console.log('[WhatsApp] Iniciando conexão...');

    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);

    const sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      browser: ['Fidelidade WhatsApp', 'Chrome', '120.0.0.0'],
      syncFullHistory: false,
      markOnlineOnConnect: true,
      fireInitQueries: false,
      connectTimeoutMs: 60_000,
      keepAliveIntervalMs: 30_000,
    });

    // Evento de atualização de conexão
    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;

      console.log('[WhatsApp] Connection update:', { connection, hasQR: !!qr });

      // Gerar QR code quando solicitado
      if (qr) {
        try {
          console.log('[WhatsApp] Gerando QR code...');
          const qrDataUrl = await qrcode.toDataURL(qr);
          whatsappSession.qrCode = qrDataUrl;
          console.log('[WhatsApp] ✓ QR Code gerado com sucesso');
        } catch (err) {
          console.error('[WhatsApp] Erro ao gerar QR code:', err);
        }
      }

      // Tratamento de desconexão
      if (connection === 'close') {
        const shouldReconnect = (lastDisconnect?.error as Boom)?.output?.statusCode !== DisconnectReason.loggedOut;
        console.log('[WhatsApp] Desconectado. Reconectar?', shouldReconnect);

        whatsappSession.isConnected = false;
        whatsappSession.isInitializing = false;

        if (shouldReconnect) {
          console.log('[WhatsApp] Tentando reconectar em 5 segundos...');
          setTimeout(() => {
            whatsappSession.isInitializing = false;
            initializeWhatsApp().catch(err => console.error('[WhatsApp] Erro ao reconectar:', err));
          }, 5000);
        } else {
          console.log('[WhatsApp] Desconectado permanentemente');
          whatsappSession.qrCode = null;
          whatsappSession.socket = null;
        }
      }

      // Conexão estabelecida
      if (connection === 'open') {
        whatsappSession.isConnected = true;
        whatsappSession.qrCode = null;
        whatsappSession.isInitializing = false;
        console.log('[WhatsApp] ✓ Conectado com sucesso!');

        // Tentar obter informações do telefone
        try {
          const phoneNumber = sock.user?.id?.split(':')[0];
          if (phoneNumber) {
            whatsappSession.phoneNumber = phoneNumber;
            console.log('[WhatsApp] Número:', phoneNumber);
          }
        } catch (err) {
          console.error('[WhatsApp] Erro ao obter número:', err);
        }
      }
    });

    // Salvar credenciais quando atualizadas
    sock.ev.on('creds.update', saveCreds);

    // Evento de mensagens recebidas
    sock.ev.on('messages.upsert', async (m) => {
      console.log('[WhatsApp] Nova mensagem:', m.messages.length);
    });



    whatsappSession.socket = sock;
    return sock;
  } catch (err) {
    console.error('[WhatsApp] Erro ao inicializar:', err);
    whatsappSession.isInitializing = false;
    throw err;
  }
}

export async function sendMessage(phoneNumber: string, message: string) {
  if (!whatsappSession.socket || !whatsappSession.isConnected) {
    throw new Error('WhatsApp não está conectado');
  }

  try {
    const jid = phoneNumber.includes('@') ? phoneNumber : `${phoneNumber}@s.whatsapp.net`;

    await whatsappSession.socket.sendMessage(jid, {
      text: message,
    });

    return { success: true, message: 'Mensagem enviada' };
  } catch (err) {
    console.error('[WhatsApp] Erro ao enviar mensagem:', err);
    throw err;
  }
}

export async function sendBulkMessages(
  recipients: Array<{ phone: string; name: string }>,
  message: string,
  delayMs: number = 1000
) {
  if (!whatsappSession.socket || !whatsappSession.isConnected) {
    throw new Error('WhatsApp não está conectado');
  }

  const results = [];

  for (const recipient of recipients) {
    try {
      const jid = recipient.phone.includes('@') ? recipient.phone : `${recipient.phone}@s.whatsapp.net`;

      // Personalizar mensagem com nome
      const personalizedMessage = message.replace('{nome}', recipient.name);

      await whatsappSession.socket.sendMessage(jid, {
        text: personalizedMessage,
      });

      results.push({
        phone: recipient.phone,
        status: 'sent',
        error: null,
      });

      // Delay entre mensagens para não ser bloqueado
      await new Promise(resolve => setTimeout(resolve, delayMs));
    } catch (err) {
      results.push({
        phone: recipient.phone,
        status: 'error',
        error: (err as Error).message,
      });
    }
  }

  return results;
}

export function getWhatsAppStatus() {
  return {
    isConnected: whatsappSession.isConnected,
    qrCode: whatsappSession.qrCode,
    phoneNumber: whatsappSession.phoneNumber,
    isInitializing: whatsappSession.isInitializing,
  };
}

export function disconnectWhatsApp() {
  if (whatsappSession.socket) {
    whatsappSession.socket.end();
    whatsappSession.isConnected = false;
    whatsappSession.qrCode = null;
    whatsappSession.phoneNumber = null;
    whatsappSession.isInitializing = false;
    whatsappSession.socket = null;
    console.log('[WhatsApp] Desconectado');
  }
}
