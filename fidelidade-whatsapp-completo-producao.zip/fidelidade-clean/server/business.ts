import { getRulesConfig, getWalletByCustomerId, updateWallet, createTransaction, updateCustomer, getCustomerByPhone } from "./db";
import type { Customer, Wallet } from "../drizzle/schema";
import { Decimal } from "decimal.js";

/**
 * Calcula pontos ganhos em uma compra
 */
export async function calculatePointsEarned(amount: number, campaignMultiplier = 1): Promise<number> {
  const rules = await getRulesConfig();
  if (!rules) {
    // Padrão: 1 real = 1 ponto
    return Math.floor(amount * campaignMultiplier);
  }
  
  const pointsPerReal = parseFloat(rules.pointsPerReal.toString());
  return Math.floor(amount * pointsPerReal * campaignMultiplier);
}

/**
 * Calcula cashback ganho em uma compra baseado no tier do cliente
 */
export async function calculateCashbackEarned(amount: number, tier: string): Promise<string> {
  const rules = await getRulesConfig();
  if (!rules) {
    // Padrão: 5% de cashback
    return new Decimal(amount).times(0.05).toFixed(2);
  }

  let cashbackPercentage: Decimal;
  
  switch (tier) {
    case "ouro":
      cashbackPercentage = new Decimal(rules.ouroCashback.toString());
      break;
    case "prata":
      cashbackPercentage = new Decimal(rules.prataCashback.toString());
      break;
    case "bronze":
    default:
      cashbackPercentage = new Decimal(rules.bronzeCashback.toString());
  }

  return new Decimal(amount).times(cashbackPercentage).dividedBy(100).toFixed(2);
}

/**
 * Determina o tier do cliente baseado no total gasto
 */
export async function calculateTier(totalSpent: number): Promise<string> {
  const rules = await getRulesConfig();
  if (!rules) {
    // Padrão: bronze < 1500, prata < 3000, ouro >= 3000
    if (totalSpent >= 3000) return "ouro";
    if (totalSpent >= 1500) return "prata";
    return "bronze";
  }

  const ouroThreshold = parseFloat(rules.ouroThreshold.toString());
  const prataThreshold = parseFloat(rules.prataThreshold.toString());

  if (totalSpent >= ouroThreshold) return "ouro";
  if (totalSpent >= prataThreshold) return "prata";
  return "bronze";
}

/**
 * Processa uma compra: adiciona pontos e cashback
 */
export async function processPurchase(
  customerId: number,
  amount: number,
  orderId?: string,
  campaignMultiplier = 1
): Promise<{ points: number; cashback: string; newTier: string }> {
  const wallet = await getWalletByCustomerId(customerId);
  if (!wallet) {
    throw new Error(`Wallet not found for customer ${customerId}`);
  }

  const customer = await getCustomerByPhone("");
  if (!customer) {
    throw new Error(`Customer not found with ID ${customerId}`);
  }

  // Calcula pontos e cashback
  const pointsEarned = await calculatePointsEarned(amount, campaignMultiplier);
  const cashbackEarned = await calculateCashbackEarned(amount, customer.tier);

  // Atualiza wallet
  const newPointsBalance = wallet.pointsBalance + pointsEarned;
  const newCashbackBalance = new Decimal(wallet.cashbackBalance.toString())
    .plus(cashbackEarned)
    .toFixed(2);

  // Calcula novo tier
  const newTotalSpent = parseFloat(customer.totalSpent.toString()) + amount;
  const newTier = await calculateTier(newTotalSpent);

  // Atualiza customer
  await updateCustomer(customerId, {
    totalSpent: new Decimal(newTotalSpent).toFixed(2),
    tier: newTier as any,
    lastPurchaseDate: new Date(),
  });

  // Atualiza wallet
  const expirationDate = new Date();
  const rules = await getRulesConfig();
  const expirationDays = rules?.pointsExpirationDays || 90;
  expirationDate.setDate(expirationDate.getDate() + expirationDays);

  await updateWallet(customerId, {
    pointsBalance: newPointsBalance,
    cashbackBalance: newCashbackBalance as any,
    pointsExpirationDate: expirationDate,
  });

  // Registra transações
  await createTransaction({
    customerId,
    orderId,
    type: "purchase",
    amount: new Decimal(amount).toFixed(2) as any,
    description: `Compra de R$ ${amount.toFixed(2)}`,
  });

  await createTransaction({
    customerId,
    orderId,
    type: "points_earned",
    amount: new Decimal(amount).toFixed(2) as any,
    pointsEarned,
    description: `${pointsEarned} pontos ganhos`,
  });

  await createTransaction({
    customerId,
    orderId,
    type: "cashback_earned",
    amount: new Decimal(amount).toFixed(2) as any,
    cashbackEarned: new Decimal(cashbackEarned).toFixed(2) as any,
    description: `R$ ${cashbackEarned} de cashback ganho`,
  });

  return {
    points: newPointsBalance,
    cashback: newCashbackBalance,
    newTier,
  };
}

/**
 * Resgata pontos para cashback
 */
export async function redeemPoints(
  customerId: number,
  pointsToRedeem: number
): Promise<{ newPointsBalance: number; newCashbackBalance: string }> {
  const wallet = await getWalletByCustomerId(customerId);
  if (!wallet) {
    throw new Error(`Wallet not found for customer ${customerId}`);
  }

  if (wallet.pointsBalance < pointsToRedeem) {
    throw new Error(`Insufficient points. Available: ${wallet.pointsBalance}, Requested: ${pointsToRedeem}`);
  }

  // Converte pontos para cashback (1 ponto = R$ 0.01)
  const cashbackValue = new Decimal(pointsToRedeem).times(0.01).toFixed(2);

  const newPointsBalance = wallet.pointsBalance - pointsToRedeem;
  const newCashbackBalance = new Decimal(wallet.cashbackBalance.toString())
    .plus(cashbackValue)
    .toFixed(2);

  await updateWallet(customerId, {
    pointsBalance: newPointsBalance,
    cashbackBalance: newCashbackBalance as any,
  });

  await createTransaction({
    customerId,
    type: "redemption",
    amount: new Decimal(cashbackValue).toFixed(2) as any,
    pointsEarned: -pointsToRedeem,
    description: `${pointsToRedeem} pontos resgatados para R$ ${cashbackValue}`,
  });

  return {
    newPointsBalance,
    newCashbackBalance,
  };
}

/**
 * Usa cashback em uma compra
 */
export async function useCashback(
  customerId: number,
  cashbackAmount: number
): Promise<{ newCashbackBalance: string }> {
  const wallet = await getWalletByCustomerId(customerId);
  if (!wallet) {
    throw new Error(`Wallet not found for customer ${customerId}`);
  }

  const currentCashback = parseFloat(wallet.cashbackBalance.toString());
  if (currentCashback < cashbackAmount) {
    throw new Error(`Insufficient cashback. Available: R$ ${currentCashback.toFixed(2)}, Requested: R$ ${cashbackAmount.toFixed(2)}`);
  }

  const newCashbackBalance = new Decimal(currentCashback)
    .minus(cashbackAmount)
    .toFixed(2);

  await updateWallet(customerId, {
    cashbackBalance: newCashbackBalance as any,
  });

  await createTransaction({
    customerId,
    type: "cashback_used",
    amount: new Decimal(cashbackAmount).toFixed(2) as any,
    description: `R$ ${cashbackAmount.toFixed(2)} de cashback utilizado`,
  });

  return {
    newCashbackBalance,
  };
}

/**
 * Adiciona bônus de aniversário
 */
export async function addBirthdayBonus(customerId: number): Promise<{ pointsAdded: number }> {
  const wallet = await getWalletByCustomerId(customerId);
  if (!wallet) {
    throw new Error(`Wallet not found for customer ${customerId}`);
  }

  const bonusPoints = 100;
  const newPointsBalance = wallet.pointsBalance + bonusPoints;

  await updateWallet(customerId, {
    pointsBalance: newPointsBalance,
  });

  await createTransaction({
    customerId,
    type: "points_earned",
    amount: "0" as any,
    pointsEarned: bonusPoints,
    description: "Bônus de aniversário: 100 pontos",
  });

  return {
    pointsAdded: bonusPoints,
  };
}

/**
 * Adiciona bônus de primeira compra
 */
export async function addFirstPurchaseBonus(customerId: number): Promise<{ cashbackAdded: string }> {
  const wallet = await getWalletByCustomerId(customerId);
  if (!wallet) {
    throw new Error(`Wallet not found for customer ${customerId}`);
  }

  const bonusCashback = "20.00";
  const newCashbackBalance = new Decimal(wallet.cashbackBalance.toString())
    .plus(bonusCashback)
    .toFixed(2);

  await updateWallet(customerId, {
    cashbackBalance: newCashbackBalance as any,
  });

  await createTransaction({
    customerId,
    type: "cashback_earned",
    amount: "0" as any,
    cashbackEarned: new Decimal(bonusCashback).toFixed(2) as any,
    description: "Bônus de primeira compra: R$ 20,00",
  });

  return {
    cashbackAdded: bonusCashback,
  };
}
