import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Servir arquivos estáticos do cliente
// __dirname = /app/dist (onde dist/index.js está)
// publicDir deve ser /app/dist/public
const publicDir = join(__dirname, 'public');
app.use(express.static(publicDir));

// SPA fallback - redirecionar todas as rotas para index.html
app.get('*', (req, res) => {
  const indexPath = join(publicDir, 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      console.error('Erro ao servir index.html:', err);
      res.status(500).json({ error: 'Não foi possível carregar a aplicação' });
    }
  });
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Erro:', err);
  res.status(500).json({ error: 'Internal Server Error' });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
