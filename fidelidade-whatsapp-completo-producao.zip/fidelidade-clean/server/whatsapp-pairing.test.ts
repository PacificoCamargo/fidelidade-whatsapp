import { describe, it, expect, beforeEach } from 'vitest';
import {
  initiatePairing,
  getPairingStatus,
  isConnected,
  disconnectWhatsApp,
  getPairingCode,
  getPairingLink,
  isCodeValid,
} from './whatsapp-pairing';

describe('WhatsApp Pairing Module', () => {
  beforeEach(async () => {
    // Limpar estado antes de cada teste
    await disconnectWhatsApp();
  });

  it('should generate a pairing code with 8 digits', async () => {
    const result = await initiatePairing('5515996592265');
    
    expect(result.pairingCode).toBeDefined();
    expect(result.pairingCode).toMatch(/^\d{8}$/);
  });

  it('should generate a pairing link', async () => {
    const result = await initiatePairing('5515996592265');
    
    expect(result.pairingLink).toBeDefined();
    expect(result.pairingLink).toContain('https://wa.me/?code=');
    expect(result.pairingLink).toContain(result.pairingCode);
  });

  it('should store pairing code and link in state', async () => {
    const result = await initiatePairing('5515996592265');
    const status = getPairingStatus();
    
    expect(status.pairingCode).toBe(result.pairingCode);
    expect(status.pairingLink).toBe(result.pairingLink);
    expect(status.phoneNumber).toBe('5515996592265');
  });

  it('should return pairing code', async () => {
    await initiatePairing('5515996592265');
    const code = getPairingCode();
    
    expect(code).toBeDefined();
    expect(code).toMatch(/^\d{8}$/);
  });

  it('should return pairing link', async () => {
    await initiatePairing('5515996592265');
    const link = getPairingLink();
    
    expect(link).toBeDefined();
    expect(link).toContain('https://wa.me/?code=');
  });

  it('should validate code as valid when just generated', async () => {
    await initiatePairing('5515996592265');
    const valid = isCodeValid();
    
    expect(valid).toBe(true);
  });

  it('should not be connected initially', async () => {
    const connected = isConnected();
    
    expect(connected).toBe(false);
  });

  it('should disconnect and clear state', async () => {
    await initiatePairing('5515996592265');
    await disconnectWhatsApp();
    
    const status = getPairingStatus();
    
    expect(status.pairingCode).toBeNull();
    expect(status.pairingLink).toBeNull();
    expect(status.phoneNumber).toBeNull();
    expect(isConnected()).toBe(false);
  });

  it('should reject invalid phone numbers', async () => {
    await expect(initiatePairing('123')).rejects.toThrow('Número de telefone inválido');
  });

  it('should reject empty phone numbers', async () => {
    await expect(initiatePairing('')).rejects.toThrow('Número de telefone inválido');
  });

  it('should generate different codes on each call', async () => {
    const result1 = await initiatePairing('5515996592265');
    await disconnectWhatsApp();
    
    const result2 = await initiatePairing('5515996592265');
    
    expect(result1.pairingCode).not.toBe(result2.pairingCode);
  });
});
