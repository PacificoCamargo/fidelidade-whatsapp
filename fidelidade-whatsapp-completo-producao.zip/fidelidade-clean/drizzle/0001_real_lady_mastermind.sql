CREATE TABLE `campaigns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('reactivation','last_chance','nps','promo','birthday','first_purchase') NOT NULL,
	`segment` varchar(100),
	`triggerRule` text,
	`messageTemplate` text,
	`pointsMultiplier` int DEFAULT 1,
	`cashbackBonus` decimal(12,2) DEFAULT '0',
	`active` boolean NOT NULL DEFAULT true,
	`startDate` timestamp,
	`endDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `campaigns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`phone` varchar(20) NOT NULL,
	`email` varchar(320),
	`birthDate` date,
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`tier` enum('bronze','prata','ouro') NOT NULL DEFAULT 'bronze',
	`totalSpent` decimal(12,2) NOT NULL DEFAULT '0',
	`lastPurchaseDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`),
	CONSTRAINT `customers_phone_unique` UNIQUE(`phone`)
);
--> statement-breakpoint
CREATE TABLE `redemptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`rewardId` int NOT NULL,
	`status` enum('pending','used','expired','cancelled') NOT NULL DEFAULT 'pending',
	`code` varchar(50),
	`expiresAt` timestamp,
	`usedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `redemptions_id` PRIMARY KEY(`id`),
	CONSTRAINT `redemptions_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `referrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referrerId` int NOT NULL,
	`referredPhone` varchar(20) NOT NULL,
	`status` enum('pending','converted') NOT NULL DEFAULT 'pending',
	`bonusGenerated` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `referrals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `rewards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`type` enum('discount','cashback','gift','experience') NOT NULL,
	`value` decimal(12,2) NOT NULL,
	`pointsRequired` int NOT NULL,
	`expirationDays` int DEFAULT 90,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `rewards_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `rulesConfig` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`pointsPerReal` decimal(5,2) NOT NULL DEFAULT '1',
	`cashbackPercentage` decimal(5,2) NOT NULL DEFAULT '5',
	`pointsExpirationDays` int NOT NULL DEFAULT 90,
	`bronzeCashback` decimal(5,2) NOT NULL DEFAULT '5',
	`prataThreshold` decimal(12,2) NOT NULL DEFAULT '1500',
	`prataCashback` decimal(5,2) NOT NULL DEFAULT '7',
	`ouroThreshold` decimal(12,2) NOT NULL DEFAULT '3000',
	`ouroCashback` decimal(5,2) NOT NULL DEFAULT '10',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `rulesConfig_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`orderId` varchar(100),
	`type` enum('purchase','points_earned','cashback_earned','redemption','cashback_used','adjustment') NOT NULL,
	`amount` decimal(12,2) NOT NULL,
	`pointsEarned` int DEFAULT 0,
	`cashbackEarned` decimal(12,2) DEFAULT '0',
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wallets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`pointsBalance` int NOT NULL DEFAULT 0,
	`cashbackBalance` decimal(12,2) NOT NULL DEFAULT '0',
	`pointsExpirationDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wallets_id` PRIMARY KEY(`id`)
);
