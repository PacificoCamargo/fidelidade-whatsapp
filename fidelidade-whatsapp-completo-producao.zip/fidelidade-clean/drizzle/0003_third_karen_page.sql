CREATE TABLE `automation_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`triggerId` int NOT NULL,
	`customerId` int,
	`messageId` int,
	`status` enum('pending','sent','failed','skipped') NOT NULL DEFAULT 'pending',
	`errorMessage` text,
	`executedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `automation_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `automation_triggers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`triggerType` enum('points_accumulated','cashback_available','points_expiring','birthday','tier_upgrade','purchase_milestone') NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`messageTemplate` text NOT NULL,
	`conditions` text,
	`lastExecuted` timestamp,
	`nextExecution` timestamp,
	`executionCount` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `automation_triggers_id` PRIMARY KEY(`id`)
);
