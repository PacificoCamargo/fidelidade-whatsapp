CREATE TABLE `campaign_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` int NOT NULL,
	`customerId` int NOT NULL,
	`status` enum('pending','sent','failed','delivered') DEFAULT 'pending',
	`sentAt` timestamp,
	`deliveredAt` timestamp,
	`error` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `campaign_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(50) NOT NULL,
	`barcode` varchar(100),
	`description` varchar(500) NOT NULL,
	`size` varchar(50),
	`color` varchar(100),
	`quantity` int NOT NULL DEFAULT 0,
	`unitPrice` decimal(12,2) NOT NULL,
	`costPrice` decimal(12,2) DEFAULT '0',
	`salePrice` decimal(12,2) NOT NULL,
	`supplier` varchar(255),
	`category` varchar(100),
	`status` enum('active','inactive','discontinued') NOT NULL DEFAULT 'active',
	`brand` varchar(100),
	`lastRestockDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `products_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `stock_movements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productId` int NOT NULL,
	`movementType` enum('in','out','adjustment','return') NOT NULL,
	`quantity` int NOT NULL,
	`reason` varchar(255),
	`reference` varchar(100),
	`previousQuantity` int,
	`newQuantity` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stock_movements_id` PRIMARY KEY(`id`)
);
