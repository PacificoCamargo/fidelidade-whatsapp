import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, date } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ============ FIDELIDADE TABLES ============

/**
 * Clientes do programa de fidelidade
 */
export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }).notNull().unique(),
  email: varchar("email", { length: 320 }),
  birthDate: date("birthDate"),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  tier: mysqlEnum("tier", ["bronze", "prata", "ouro"]).default("bronze").notNull(),
  totalSpent: decimal("totalSpent", { precision: 12, scale: 2 }).default("0").notNull(),
  lastPurchaseDate: timestamp("lastPurchaseDate"),
  cpf: varchar("cpf", { length: 14 }).unique(),
  cnpj: varchar("cnpj", { length: 18 }).unique(),
  gender: varchar("gender", { length: 20 }),
  maritalStatus: varchar("maritalStatus", { length: 50 }),
  personType: varchar("personType", { length: 50 }),
  address: varchar("address", { length: 255 }),
  addressNumber: varchar("addressNumber", { length: 20 }),
  neighborhood: varchar("neighborhood", { length: 100 }),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 2 }),
  secondaryPhone: varchar("secondaryPhone", { length: 20 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = typeof customers.$inferInsert;

/**
 * Carteira de pontos e cashback do cliente
 */
export const wallets = mysqlTable("wallets", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull(),
  pointsBalance: int("pointsBalance").default(0).notNull(),
  cashbackBalance: decimal("cashbackBalance", { precision: 12, scale: 2 }).default("0").notNull(),
  pointsExpirationDate: timestamp("pointsExpirationDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Wallet = typeof wallets.$inferSelect;
export type InsertWallet = typeof wallets.$inferInsert;

/**
 * Transações de compra, acúmulo e resgate
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull(),
  orderId: varchar("orderId", { length: 100 }),
  type: mysqlEnum("type", ["purchase", "points_earned", "cashback_earned", "redemption", "cashback_used", "adjustment"]).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  pointsEarned: int("pointsEarned").default(0),
  cashbackEarned: decimal("cashbackEarned", { precision: 12, scale: 2 }).default("0"),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Recompensas disponíveis no programa
 */
export const rewards = mysqlTable("rewards", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["discount", "cashback", "gift", "experience"]).notNull(),
  value: decimal("value", { precision: 12, scale: 2 }).notNull(),
  pointsRequired: int("pointsRequired").notNull(),
  expirationDays: int("expirationDays").default(90),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Reward = typeof rewards.$inferSelect;
export type InsertReward = typeof rewards.$inferInsert;

/**
 * Resgates de recompensas por cliente
 */
export const redemptions = mysqlTable("redemptions", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull(),
  rewardId: int("rewardId").notNull(),
  status: mysqlEnum("status", ["pending", "used", "expired", "cancelled"]).default("pending").notNull(),
  code: varchar("code", { length: 50 }).unique(),
  expiresAt: timestamp("expiresAt"),
  usedAt: timestamp("usedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Redemption = typeof redemptions.$inferSelect;
export type InsertRedemption = typeof redemptions.$inferInsert;

/**
 * Campanhas promocionais
 */
export const campaigns = mysqlTable("campaigns", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["reactivation", "last_chance", "nps", "promo", "birthday", "first_purchase"]).notNull(),
  segment: varchar("segment", { length: 100 }),
  triggerRule: text("triggerRule"),
  messageTemplate: text("messageTemplate"),
  pointsMultiplier: int("pointsMultiplier").default(1),
  cashbackBonus: decimal("cashbackBonus", { precision: 12, scale: 2 }).default("0"),
  active: boolean("active").default(true).notNull(),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = typeof campaigns.$inferInsert;

/**
 * Indicações/Referências entre clientes
 */
export const referrals = mysqlTable("referrals", {
  id: int("id").autoincrement().primaryKey(),
  referrerId: int("referrerId").notNull(),
  referredPhone: varchar("referredPhone", { length: 20 }).notNull(),
  status: mysqlEnum("status", ["pending", "converted"]).default("pending").notNull(),
  bonusGenerated: boolean("bonusGenerated").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

/**
 * Configurações de regras do programa
 */
export const rulesConfig = mysqlTable("rulesConfig", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  pointsPerReal: decimal("pointsPerReal", { precision: 5, scale: 2 }).default("1").notNull(),
  cashbackPercentage: decimal("cashbackPercentage", { precision: 5, scale: 2 }).default("5").notNull(),
  pointsExpirationDays: int("pointsExpirationDays").default(90).notNull(),
  bronzeCashback: decimal("bronzeCashback", { precision: 5, scale: 2 }).default("5").notNull(),
  prataThreshold: decimal("prataThreshold", { precision: 12, scale: 2 }).default("1500").notNull(),
  prataCashback: decimal("prataCashback", { precision: 5, scale: 2 }).default("7").notNull(),
  ouroThreshold: decimal("ouroThreshold", { precision: 12, scale: 2 }).default("3000").notNull(),
  ouroCashback: decimal("ouroCashback", { precision: 5, scale: 2 }).default("10").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type RulesConfig = typeof rulesConfig.$inferSelect;
export type InsertRulesConfig = typeof rulesConfig.$inferInsert;

// ============ WHATSAPP TABLES ============

/**
 * Sessões WhatsApp Web conectadas
 */
export const whatsappSessions = mysqlTable("whatsapp_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  phoneNumber: varchar("phoneNumber", { length: 20 }).notNull().unique(),
  sessionData: text("sessionData"),
  qrCode: text("qrCode"),
  isConnected: boolean("isConnected").default(false).notNull(),
  lastConnected: timestamp("lastConnected"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WhatsAppSession = typeof whatsappSessions.$inferSelect;
export type InsertWhatsAppSession = typeof whatsappSessions.$inferInsert;

/**
 * Mensagens WhatsApp enviadas e recebidas
 */
export const whatsappMessages = mysqlTable("whatsapp_messages", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  customerId: int("customerId"),
  phoneNumber: varchar("phoneNumber", { length: 20 }).notNull(),
  message: text("message").notNull(),
  messageType: mysqlEnum("messageType", ["text", "image", "document", "template"])
    .default("text")
    .notNull(),
  status: mysqlEnum("status", ["pending", "sent", "delivered", "failed"])
    .default("pending")
    .notNull(),
  sentAt: timestamp("sentAt"),
  failureReason: text("failureReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WhatsAppMessage = typeof whatsappMessages.$inferSelect;
export type InsertWhatsAppMessage = typeof whatsappMessages.$inferInsert;


// ============ AUTOMATION TABLES ============

/**
 * Triggers de automação para envio de mensagens
 */
export const automationTriggers = mysqlTable("automation_triggers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  triggerType: mysqlEnum("triggerType", [
    "points_accumulated",
    "cashback_available",
    "points_expiring",
    "birthday",
    "tier_upgrade",
    "purchase_milestone",
  ])
    .notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  messageTemplate: text("messageTemplate").notNull(),
  conditions: text("conditions"), // JSON string with conditions
  lastExecuted: timestamp("lastExecuted"),
  nextExecution: timestamp("nextExecution"),
  executionCount: int("executionCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AutomationTrigger = typeof automationTriggers.$inferSelect;
export type InsertAutomationTrigger = typeof automationTriggers.$inferInsert;

/**
 * Logs de execução de automações
 */
export const automationLogs = mysqlTable("automation_logs", {
  id: int("id").autoincrement().primaryKey(),
  triggerId: int("triggerId").notNull(),
  customerId: int("customerId"),
  messageId: int("messageId"),
  status: mysqlEnum("status", ["pending", "sent", "failed", "skipped"])
    .default("pending")
    .notNull(),
  errorMessage: text("errorMessage"),
  executedAt: timestamp("executedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AutomationLog = typeof automationLogs.$inferSelect;
export type InsertAutomationLog = typeof automationLogs.$inferInsert;

// ============ AI ANALYTICS TABLES ============

/**
 * Análises de frequência de vendas por cliente
 */
export const salesFrequencyAnalysis = mysqlTable("sales_frequency_analysis", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull(),
  lastPurchaseDate: timestamp("lastPurchaseDate"),
  averagePurchaseFrequencyDays: int("averagePurchaseFrequencyDays"),
  daysSinceLastPurchase: int("daysSinceLastPurchase"),
  purchaseCount: int("purchaseCount").default(0),
  totalSpent: decimal("totalSpent", { precision: 12, scale: 2 }).default("0"),
  averageTicket: decimal("averageTicket", { precision: 12, scale: 2 }).default("0"),
  riskStatus: mysqlEnum("riskStatus", ["healthy", "at_risk", "critical"]).default("healthy"),
  aiAnalysis: text("aiAnalysis"), // JSON com análise da IA
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SalesFrequencyAnalysis = typeof salesFrequencyAnalysis.$inferSelect;
export type InsertSalesFrequencyAnalysis = typeof salesFrequencyAnalysis.$inferInsert;

/**
 * Recomendações de cashback e descontos geradas por IA
 */
export const aiRecommendations = mysqlTable("ai_recommendations", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull(),
  type: mysqlEnum("type", ["cashback_increase", "discount", "free_shipping", "bonus_points"]).notNull(),
  currentValue: decimal("currentValue", { precision: 5, scale: 2 }),
  suggestedValue: decimal("suggestedValue", { precision: 5, scale: 2 }).notNull(),
  reason: text("reason"), // Motivo da recomendação
  confidence: int("confidence"), // 0-100, confiança da IA
  aiInsight: text("aiInsight"), // Análise detalhada da IA
  status: mysqlEnum("status", ["pending", "applied", "rejected"]).default("pending"),
  appliedAt: timestamp("appliedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AIRecommendation = typeof aiRecommendations.$inferSelect;
export type InsertAIRecommendation = typeof aiRecommendations.$inferInsert;

/**
 * Análise de comportamento de compra por produto
 */
export const productBehaviorAnalysis = mysqlTable("product_behavior_analysis", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull(),
  productCategory: varchar("productCategory", { length: 255 }).notNull(),
  purchaseCount: int("purchaseCount").default(0),
  totalSpent: decimal("totalSpent", { precision: 12, scale: 2 }).default("0"),
  lastPurchaseDate: timestamp("lastPurchaseDate"),
  averagePurchaseFrequencyDays: int("averagePurchaseFrequencyDays"),
  recommendedProducts: text("recommendedProducts"), // JSON array de produtos recomendados
  crossSellOpportunity: text("crossSellOpportunity"), // Oportunidade de venda cruzada
  upsellOpportunity: text("upsellOpportunity"), // Oportunidade de venda adicional
  conversionProbability: int("conversionProbability"), // 0-100
  aiAnalysis: text("aiAnalysis"), // JSON com análise da IA
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ProductBehaviorAnalysis = typeof productBehaviorAnalysis.$inferSelect;
export type InsertProductBehaviorAnalysis = typeof productBehaviorAnalysis.$inferInsert;

/**
 * Campanhas geradas automaticamente por IA
 */
export const aiGeneratedCampaigns = mysqlTable("ai_generated_campaigns", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  targetSegment: varchar("targetSegment", { length: 100 }).notNull(),
  targetAudience: int("targetAudience"), // Quantidade de clientes alvo
  messageTemplate: text("messageTemplate").notNull(),
  cashbackBonus: decimal("cashbackBonus", { precision: 12, scale: 2 }).default("0"),
  pointsMultiplier: int("pointsMultiplier").default(1),
  recommendedSendTime: timestamp("recommendedSendTime"),
  projectedRevenue: decimal("projectedRevenue", { precision: 12, scale: 2 }),
  aiInsight: text("aiInsight"), // Análise e justificativa da IA
  status: mysqlEnum("status", ["draft", "scheduled", "sent", "completed"]).default("draft"),
  sentAt: timestamp("sentAt"),
  actualRevenue: decimal("actualRevenue", { precision: 12, scale: 2 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AIGeneratedCampaign = typeof aiGeneratedCampaigns.$inferSelect;
export type InsertAIGeneratedCampaign = typeof aiGeneratedCampaigns.$inferInsert;

// ============ WHATSAPP CAMPAIGNS MESSAGES TABLES ============

/**
 * Mensagens de campanhas enviadas
 */
export const campaignMessages = mysqlTable("campaign_messages", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").notNull(),
  customerId: int("customerId").notNull(),
  status: mysqlEnum("status", ["pending", "sent", "failed", "delivered"]).default("pending"),
  sentAt: timestamp("sentAt"),
  deliveredAt: timestamp("deliveredAt"),
  error: text("error"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CampaignMessage = typeof campaignMessages.$inferSelect;
export type InsertCampaignMessage = typeof campaignMessages.$inferInsert;

// ============ PRODUCTS TABLES ============

/**
 * Catálogo de produtos
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  barcode: varchar("barcode", { length: 100 }),
  description: varchar("description", { length: 500 }).notNull(),
  size: varchar("size", { length: 50 }),
  color: varchar("color", { length: 100 }),
  quantity: int("quantity").default(0).notNull(),
  unitPrice: decimal("unitPrice", { precision: 12, scale: 2 }).notNull(),
  costPrice: decimal("costPrice", { precision: 12, scale: 2 }).default("0"),
  salePrice: decimal("salePrice", { precision: 12, scale: 2 }).notNull(),
  supplier: varchar("supplier", { length: 255 }),
  category: varchar("category", { length: 100 }),
  status: mysqlEnum("status", ["active", "inactive", "discontinued"]).default("active").notNull(),
  brand: varchar("brand", { length: 100 }),
  lastRestockDate: timestamp("lastRestockDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Histórico de movimentação de estoque
 */
export const stockMovements = mysqlTable("stock_movements", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull(),
  movementType: mysqlEnum("movementType", ["in", "out", "adjustment", "return"]).notNull(),
  quantity: int("quantity").notNull(),
  reason: varchar("reason", { length: 255 }),
  reference: varchar("reference", { length: 100 }), // Pedido, Devolução, etc
  previousQuantity: int("previousQuantity"),
  newQuantity: int("newQuantity"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StockMovement = typeof stockMovements.$inferSelect;
export type InsertStockMovement = typeof stockMovements.$inferInsert;
