CREATE TABLE `ai_generated_campaigns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`targetSegment` varchar(100) NOT NULL,
	`targetAudience` int,
	`messageTemplate` text NOT NULL,
	`cashbackBonus` decimal(12,2) DEFAULT '0',
	`pointsMultiplier` int DEFAULT 1,
	`recommendedSendTime` timestamp,
	`projectedRevenue` decimal(12,2),
	`aiInsight` text,
	`status` enum('draft','scheduled','sent','completed') DEFAULT 'draft',
	`sentAt` timestamp,
	`actualRevenue` decimal(12,2),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ai_generated_campaigns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ai_recommendations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`type` enum('cashback_increase','discount','free_shipping','bonus_points') NOT NULL,
	`currentValue` decimal(5,2),
	`suggestedValue` decimal(5,2) NOT NULL,
	`reason` text,
	`confidence` int,
	`aiInsight` text,
	`status` enum('pending','applied','rejected') DEFAULT 'pending',
	`appliedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ai_recommendations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `product_behavior_analysis` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`productCategory` varchar(255) NOT NULL,
	`purchaseCount` int DEFAULT 0,
	`totalSpent` decimal(12,2) DEFAULT '0',
	`lastPurchaseDate` timestamp,
	`averagePurchaseFrequencyDays` int,
	`recommendedProducts` text,
	`crossSellOpportunity` text,
	`upsellOpportunity` text,
	`conversionProbability` int,
	`aiAnalysis` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `product_behavior_analysis_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sales_frequency_analysis` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`lastPurchaseDate` timestamp,
	`averagePurchaseFrequencyDays` int,
	`daysSinceLastPurchase` int,
	`purchaseCount` int DEFAULT 0,
	`totalSpent` decimal(12,2) DEFAULT '0',
	`averageTicket` decimal(12,2) DEFAULT '0',
	`riskStatus` enum('healthy','at_risk','critical') DEFAULT 'healthy',
	`aiAnalysis` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sales_frequency_analysis_id` PRIMARY KEY(`id`)
);
