CREATE TABLE `whatsapp_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`customerId` int,
	`phoneNumber` varchar(20) NOT NULL,
	`message` text NOT NULL,
	`messageType` enum('text','image','document','template') NOT NULL DEFAULT 'text',
	`status` enum('pending','sent','delivered','failed') NOT NULL DEFAULT 'pending',
	`sentAt` timestamp,
	`failureReason` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `whatsapp_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `whatsapp_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`phoneNumber` varchar(20) NOT NULL,
	`sessionData` text,
	`qrCode` text,
	`isConnected` boolean NOT NULL DEFAULT false,
	`lastConnected` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `whatsapp_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `whatsapp_sessions_phoneNumber_unique` UNIQUE(`phoneNumber`)
);
