ALTER TABLE `customers` ADD `cpf` varchar(14);--> statement-breakpoint
ALTER TABLE `customers` ADD `cnpj` varchar(18);--> statement-breakpoint
ALTER TABLE `customers` ADD `gender` varchar(20);--> statement-breakpoint
ALTER TABLE `customers` ADD `maritalStatus` varchar(50);--> statement-breakpoint
ALTER TABLE `customers` ADD `personType` varchar(50);--> statement-breakpoint
ALTER TABLE `customers` ADD `address` varchar(255);--> statement-breakpoint
ALTER TABLE `customers` ADD `addressNumber` varchar(20);--> statement-breakpoint
ALTER TABLE `customers` ADD `neighborhood` varchar(100);--> statement-breakpoint
ALTER TABLE `customers` ADD `city` varchar(100);--> statement-breakpoint
ALTER TABLE `customers` ADD `state` varchar(2);--> statement-breakpoint
ALTER TABLE `customers` ADD `secondaryPhone` varchar(20);--> statement-breakpoint
ALTER TABLE `customers` ADD CONSTRAINT `customers_cpf_unique` UNIQUE(`cpf`);--> statement-breakpoint
ALTER TABLE `customers` ADD CONSTRAINT `customers_cnpj_unique` UNIQUE(`cnpj`);