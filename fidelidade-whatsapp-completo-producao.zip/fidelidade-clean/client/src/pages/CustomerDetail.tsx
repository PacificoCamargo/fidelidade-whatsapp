import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useParams } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function CustomerDetail() {
  const [, setLocation] = useLocation();
  const { id } = useParams();
  const customerId = parseInt(id || "0");

  const { data: wallet } = trpc.fidelidade.getWallet.useQuery({ customerId });
  const { data: transactions } = trpc.fidelidade.getTransactions.useQuery({ customerId, limit: 50 });
  const { data: redemptions } = trpc.fidelidade.getRedemptions.useQuery({ customerId });

  const getTierColor = (tier: string) => {
    switch (tier) {
      case "ouro":
        return "bg-yellow-100 text-yellow-800";
      case "prata":
        return "bg-gray-100 text-gray-800";
      case "bronze":
      default:
        return "bg-orange-100 text-orange-800";
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setLocation("/customers")}
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Detalhes do Cliente</h1>
            <p className="text-muted-foreground mt-2">ID: {customerId}</p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Pontos Disponíveis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{wallet?.pointsBalance || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Expiram em {wallet?.pointsExpirationDate ? new Date(wallet.pointsExpirationDate).toLocaleDateString('pt-BR') : "-"}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Cashback Disponível</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                R$ {wallet ? parseFloat(wallet.cashbackBalance.toString()).toFixed(2) : "0.00"}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Crédito para usar</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Resgates Pendentes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {redemptions?.filter(r => r.status === "pending").length || 0}
              </div>
              <p className="text-xs text-muted-foreground mt-1">Aguardando uso</p>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Histórico de Transações</CardTitle>
            <CardDescription>Últimas 50 transações</CardDescription>
          </CardHeader>
          <CardContent>
            {!transactions || transactions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Nenhuma transação registrada
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium">Data</th>
                      <th className="text-left py-3 px-4 font-medium">Tipo</th>
                      <th className="text-left py-3 px-4 font-medium">Valor</th>
                      <th className="text-left py-3 px-4 font-medium">Pontos</th>
                      <th className="text-left py-3 px-4 font-medium">Cashback</th>
                      <th className="text-left py-3 px-4 font-medium">Descrição</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((tx) => (
                      <tr key={tx.id} className="border-b hover:bg-muted/50">
                        <td className="py-3 px-4">
                          {new Date(tx.createdAt).toLocaleDateString('pt-BR')}
                        </td>
                        <td className="py-3 px-4">
                          <Badge variant="outline">{tx.type}</Badge>
                        </td>
                        <td className="py-3 px-4">
                          R$ {parseFloat(tx.amount.toString()).toFixed(2)}
                        </td>
                        <td className="py-3 px-4">{tx.pointsEarned || 0}</td>
                        <td className="py-3 px-4">
                          R$ {tx.cashbackEarned ? parseFloat(tx.cashbackEarned.toString()).toFixed(2) : "0.00"}
                        </td>
                        <td className="py-3 px-4 text-muted-foreground">{tx.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Resgates</CardTitle>
            <CardDescription>Recompensas resgatadas</CardDescription>
          </CardHeader>
          <CardContent>
            {!redemptions || redemptions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Nenhum resgate registrado
              </div>
            ) : (
              <div className="space-y-4">
                {redemptions.map((r) => (
                  <div key={r.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Código: {r.code}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(r.createdAt).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    <Badge variant={r.status === "used" ? "default" : "secondary"}>
                      {r.status === "used" ? "Utilizado" : r.status === "expired" ? "Expirado" : "Pendente"}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
