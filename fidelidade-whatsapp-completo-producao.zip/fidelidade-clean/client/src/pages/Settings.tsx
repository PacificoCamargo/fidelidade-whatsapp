import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Save } from "lucide-react";

export default function Settings() {
  const { data: rulesConfig } = trpc.fidelidade.getRulesConfig.useQuery();
  const updateRulesMutation = trpc.fidelidade.updateRulesConfig.useMutation();

  const [formData, setFormData] = useState({
    pointsPerReal: parseFloat(rulesConfig?.pointsPerReal?.toString() || "1"),
    cashbackPercentage: parseFloat(rulesConfig?.cashbackPercentage?.toString() || "5"),
    pointsExpirationDays: rulesConfig?.pointsExpirationDays || 90,
    bronzeCashback: parseFloat(rulesConfig?.bronzeCashback?.toString() || "5"),
    prataThreshold: parseFloat(rulesConfig?.prataThreshold?.toString() || "1500"),
    prataCashback: parseFloat(rulesConfig?.prataCashback?.toString() || "7"),
    ouroThreshold: parseFloat(rulesConfig?.ouroThreshold?.toString() || "3000"),
    ouroCashback: parseFloat(rulesConfig?.ouroCashback?.toString() || "10"),
  });

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async () => {
    try {
      await updateRulesMutation.mutateAsync(formData);
      alert("Configurações salvas com sucesso!");
    } catch (error) {
      alert("Erro ao salvar configurações");
      console.error(error);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
          <p className="text-muted-foreground mt-2">Configure as regras do programa de fidelidade</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Regras de Pontuação</CardTitle>
            <CardDescription>Configure como os pontos são calculados</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Pontos por Real</label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.pointsPerReal}
                  onChange={(e) => handleChange("pointsPerReal", parseFloat(e.target.value))}
                  className="mt-1"
                />
                <p className="text-xs text-muted-foreground mt-1">Quantos pontos por R$ 1,00 gasto</p>
              </div>
              <div>
                <label className="text-sm font-medium">Dias de Expiração de Pontos</label>
                <Input
                  type="number"
                  value={formData.pointsExpirationDays}
                  onChange={(e) => handleChange("pointsExpirationDays", parseInt(e.target.value))}
                  className="mt-1"
                />
                <p className="text-xs text-muted-foreground mt-1">Quantos dias até os pontos expirem</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Regras de Cashback por Tier</CardTitle>
            <CardDescription>Configure o percentual de cashback para cada nível</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h4 className="font-medium mb-4">Bronze (Padrão)</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Cashback (%)</label>
                  <Input
                    type="number"
                    step="0.1"
                    value={formData.bronzeCashback}
                    onChange={(e) => handleChange("bronzeCashback", parseFloat(e.target.value))}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>

            <div className="border-t pt-6">
              <h4 className="font-medium mb-4">Prata</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Threshold (R$)</label>
                  <Input
                    type="number"
                    step="100"
                    value={formData.prataThreshold}
                    onChange={(e) => handleChange("prataThreshold", parseFloat(e.target.value))}
                    className="mt-1"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Gasto mínimo para atingir Prata</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Cashback (%)</label>
                  <Input
                    type="number"
                    step="0.1"
                    value={formData.prataCashback}
                    onChange={(e) => handleChange("prataCashback", parseFloat(e.target.value))}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>

            <div className="border-t pt-6">
              <h4 className="font-medium mb-4">Ouro</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Threshold (R$)</label>
                  <Input
                    type="number"
                    step="100"
                    value={formData.ouroThreshold}
                    onChange={(e) => handleChange("ouroThreshold", parseFloat(e.target.value))}
                    className="mt-1"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Gasto mínimo para atingir Ouro</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Cashback (%)</label>
                  <Input
                    type="number"
                    step="0.1"
                    value={formData.ouroCashback}
                    onChange={(e) => handleChange("ouroCashback", parseFloat(e.target.value))}
                    className="mt-1"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Integração WhatsApp</CardTitle>
            <CardDescription>Configure as credenciais da WhatsApp Business API</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium">Token de Acesso</label>
              <Input
                type="password"
                placeholder="Seu token de acesso do WhatsApp"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium">ID do Telefone</label>
              <Input
                type="text"
                placeholder="Seu ID de telefone do WhatsApp"
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium">ID da Conta de Negócio</label>
              <Input
                type="text"
                placeholder="Seu ID de conta de negócio"
                className="mt-1"
              />
            </div>
            <Button variant="outline" className="w-full">
              Testar Conexão
            </Button>
          </CardContent>
        </Card>

        <div className="flex gap-2">
          <Button onClick={handleSave} disabled={updateRulesMutation.isPending}>
            <Save className="w-4 h-4 mr-2" />
            {updateRulesMutation.isPending ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </div>
      </div>
    </DashboardLayout>
  );
}
