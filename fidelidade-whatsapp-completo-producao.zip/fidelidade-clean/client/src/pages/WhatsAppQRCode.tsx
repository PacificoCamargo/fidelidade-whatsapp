import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Loader2, Phone, RotateCcw } from 'lucide-react';
import { trpc } from '@/lib/trpc';

const FIXED_PHONE_NUMBER = '5515996592265';

export default function WhatsAppQRCode() {
  const [phoneNumber, setPhoneNumber] = useState(FIXED_PHONE_NUMBER);
  const [qrCodeBase64, setQrCodeBase64] = useState<string | null>(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string | null>(null);
  const [expiresIn, setExpiresIn] = useState<number | null>(null);
  const [timestamp, setTimestamp] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [isExpired, setIsExpired] = useState(false);

  const generateQRMutation = trpc.whatsapp.generateQRCode.useMutation();

  const handleGenerateQR = async () => {
    setError('');
    setQrCodeBase64(null);
    setQrCodeDataUrl(null);
    setIsExpired(false);

    try {
      const cleanNumber = FIXED_PHONE_NUMBER;
      if (cleanNumber.length < 10) {
        throw new Error('Número de telefone inválido. Use o formato: 55XXXXXXXXXXX');
      }

      console.log('[WhatsApp QR UI] Gerando QR Code para:', cleanNumber);
      const result = await generateQRMutation.mutateAsync({
        phoneNumber: cleanNumber,
      });

      if (result.success && result.qrCodeBase64) {
        setQrCodeBase64(result.qrCodeBase64);
        setQrCodeDataUrl(result.qrCodeDataUrl);
        setExpiresIn(result.expiresIn);
        setTimestamp(result.timestamp);
        console.log('[WhatsApp QR UI] QR Code gerado com sucesso');
      } else {
        setError(result.message || 'Erro ao gerar QR Code');
      }
    } catch (err: any) {
      setError(err.message || 'Erro ao gerar QR Code');
      console.error('Erro:', err);
    }
  };

  const handleRegenerate = () => {
    setQrCodeBase64(null);
    setQrCodeDataUrl(null);
    setIsExpired(false);
    handleGenerateQR();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Conectar WhatsApp com QR Code</h1>
        <p className="text-muted-foreground mt-2">
          Gere um QR Code para conectar sua conta WhatsApp
        </p>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {!qrCodeBase64 && (
        <Card>
          <CardHeader>
            <CardTitle>Gerar QR Code</CardTitle>
            <CardDescription>
              Clique no botão abaixo para gerar um QR Code para seu número WhatsApp
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Número de Telefone</label>
              <div className="flex gap-2">
                <Input
                  type="tel"
                  placeholder="55XXXXXXXXXXX"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  disabled={generateQRMutation.isPending}
                />
                <Button
                  onClick={handleGenerateQR}
                  disabled={generateQRMutation.isPending || !phoneNumber}
                >
                  {generateQRMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Phone className="mr-2 h-4 w-4" />
                      Gerar QR Code
                    </>
                  )}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Seu número deve ter WhatsApp ativo e estar acessível no celular
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {qrCodeBase64 && (
        <Card>
          <CardHeader>
            <CardTitle>QR Code Gerado</CardTitle>
            <CardDescription>
              Escaneie este QR Code com seu celular para conectar o WhatsApp
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {isExpired && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  Este QR Code expirou. Gere um novo para continuar.
                </AlertDescription>
              </Alert>
            )}

            <div className="bg-muted p-6 rounded-lg flex justify-center">
              {qrCodeDataUrl && (
                <img
                  src={qrCodeDataUrl}
                  alt="QR Code WhatsApp"
                  className="w-64 h-64 border-2 border-border rounded"
                />
              )}
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Como usar:</strong>
                <ol className="list-decimal list-inside mt-2 space-y-1 text-sm">
                  <li>Abra o WhatsApp no seu celular</li>
                  <li>Vá para Configurações → Dispositivos Conectados</li>
                  <li>Clique em "Conectar Dispositivo"</li>
                  <li>Aponte a câmera do celular para este QR Code</li>
                  <li>Confirme a conexão</li>
                </ol>
              </AlertDescription>
            </Alert>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setQrCodeBase64(null);
                  setQrCodeDataUrl(null);
                  setIsExpired(false);
                }}
              >
                Voltar
              </Button>
              <Button
                onClick={handleRegenerate}
                disabled={generateQRMutation.isPending}
                className="flex-1"
              >
                {generateQRMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Regenerando...
                  </>
                ) : (
                  <>
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Regenerar QR Code
                  </>
                )}
              </Button>
            </div>

            <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
              <p className="text-xs text-blue-900">
                <strong>Informações técnicas:</strong>
              </p>
              <ul className="text-xs text-blue-800 mt-2 space-y-1">
                <li>• QR Code válido por: {expiresIn ? `${expiresIn / 60} minutos` : 'N/A'}</li>
                <li>• Gerado em: {timestamp ? new Date(timestamp).toLocaleString() : 'N/A'}</li>
                <li>• Formato: Base64 PNG (Stateless)</li>
                <li>• Compatível com: Serverless</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
