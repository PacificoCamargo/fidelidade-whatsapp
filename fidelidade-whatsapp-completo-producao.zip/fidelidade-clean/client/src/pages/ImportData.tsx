import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { AlertCircle, CheckCircle, Upload, Download, ArrowLeft, Users, ShoppingCart, Package } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useLocation } from 'wouter';
import * as XLSX from 'xlsx';

type ImportType = 'customers' | 'sales' | 'stock' | null;

export default function ImportData() {
  const [importType, setImportType] = useState<ImportType>(null);
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');
  const [preview, setPreview] = useState<any[]>([]);
  const [, navigate] = useLocation();

  const importMutation = trpc.fidelidade.importExcelData.useMutation({
    onSuccess: (data) => {
      setStatus('success');
      let msg = '✓ Importação concluída! ';
      if (importType === 'customers') {
        msg += `${data.customersImported} clientes importados/atualizados.`;
      } else if (importType === 'sales') {
        msg += `${data.salesImported} vendas processadas.`;
      } else if (importType === 'stock') {
        msg += `${data.stockImported} produtos importados/atualizados.`;
      }
      setMessage(msg);
      setFile(null);
      setPreview([]);
      setTimeout(() => setImportType(null), 2000);
    },
    onError: (err) => {
      setStatus('error');
      setMessage(`Erro: ${err.message}`);
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!selectedFile.name.endsWith('.xlsx') && !selectedFile.name.endsWith('.xls')) {
      setStatus('error');
      setMessage('Por favor, selecione um arquivo Excel (.xlsx ou .xls)');
      return;
    }

    setFile(selectedFile);
    setStatus('idle');
    setMessage('');

    // Preview do arquivo
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheet = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheet];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);
        setPreview(jsonData.slice(0, 5));
      } catch (err) {
        setStatus('error');
        setMessage('Erro ao ler arquivo Excel');
      }
    };
    reader.readAsBinaryString(selectedFile);
  };

  const handleImport = async () => {
    if (!file || !importType) {
      setStatus('error');
      setMessage('Por favor, selecione um arquivo e tipo de importação');
      return;
    }

    setStatus('uploading');
    setMessage('Importando dados...');

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheet = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheet];
        const jsonData = XLSX.utils.sheet_to_json(worksheet);

        const payload: any = {
          customers: [],
          sales: [],
          stock: [],
        };

        if (importType === 'customers') {
          payload.customers = jsonData;
        } else if (importType === 'sales') {
          payload.sales = jsonData;
        } else if (importType === 'stock') {
          payload.stock = jsonData;
        }

        await importMutation.mutateAsync(payload);
      } catch (err) {
        setStatus('error');
        setMessage('Erro ao processar arquivo');
      }
    };
    reader.readAsBinaryString(file);
  };

  const downloadTemplate = (type: 'customers' | 'sales' | 'stock') => {
    const templates: Record<string, any[]> = {
      customers: [
        {
          CÓDIGO: 1,
          NOME: 'Maria Silva',
          ENDERECO: 'Rua das Flores, 123',
          NUMERO: '123',
          BAIRRO: 'Centro',
          CIDADE: 'São Paulo',
          CPF: '123.456.789-10',
          CNPJ: '',
          SEXO: 'FEMININO',
          'ESTADO CIVIL': 'SOLTEIRO(A)',
          PESSOA: 'PESSOA FISICA',
          STATUS: 'ATIVO',
          TELEFONE: '(11) 3000-0000',
          CELULAR: '(11) 99999-9999',
        },
      ],
      sales: [
        {
          CÓDIGO: 1,
          NOME: 'Maria Silva',
          CELULAR: '(11) 99999-9999',
          VALOR: 150.00,
          'DATA PAGO': '2026-02-23',
          'NºPEDIDO': 1001,
        },
      ],
      stock: [
        {
          Código: '001',
          'Cód. Barras': '1234567890123',
          Descrição: 'Vestido Floral',
          'Tam.': 'M',
          Cor: 'Rosa',
          Qtd: 10,
          Unitário: 199.99,
          Custo: 80.00,
          'À Vista': 199.99,
          Fornecedor: 'Fornecedor A',
          Categoria: 'Vestidos',
          Status: 'ativo',
          Marca: 'Marca X',
        },
      ],
    };

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(templates[type]);
    XLSX.utils.book_append_sheet(wb, ws, type === 'customers' ? 'Clientes' : type === 'sales' ? 'Vendas' : 'Estoque');
    XLSX.writeFile(wb, `template_${type}.xlsx`);
  };

  if (!importType) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <Button
              variant="ghost"
              onClick={() => navigate('/dashboard')}
              className="mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <h1 className="text-3xl font-bold text-slate-900">Importar Dados</h1>
            <p className="text-slate-600 mt-2">
              Escolha o tipo de dados que deseja importar
            </p>
          </div>

          {/* Import Type Selection */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Customers */}
            <Card
              className="p-6 cursor-pointer hover:shadow-lg hover:border-blue-300 transition-all border-2 border-slate-200"
              onClick={() => setImportType('customers')}
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">Cadastro de Clientes</h3>
                  <p className="text-sm text-slate-500">5.355 registros</p>
                </div>
              </div>
              <p className="text-sm text-slate-600 mb-4">
                Importar ou atualizar dados de clientes com validação de CPF/CNPJ
              </p>
              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                Selecionar
              </Button>
            </Card>

            {/* Sales */}
            <Card
              className="p-6 cursor-pointer hover:shadow-lg hover:border-green-300 transition-all border-2 border-slate-200"
              onClick={() => setImportType('sales')}
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-green-100 rounded-lg">
                  <ShoppingCart className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">Histórico de Vendas</h3>
                  <p className="text-sm text-slate-500">2.970 registros</p>
                </div>
              </div>
              <p className="text-sm text-slate-600 mb-4">
                Importar transações de vendas e processar pontos de fidelidade
              </p>
              <Button className="w-full bg-green-600 hover:bg-green-700">
                Selecionar
              </Button>
            </Card>

            {/* Stock */}
            <Card
              className="p-6 cursor-pointer hover:shadow-lg hover:border-purple-300 transition-all border-2 border-slate-200"
              onClick={() => setImportType('stock')}
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-purple-100 rounded-lg">
                  <Package className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900">Catálogo de Produtos</h3>
                  <p className="text-sm text-slate-500">1.000 produtos</p>
                </div>
              </div>
              <p className="text-sm text-slate-600 mb-4">
                Importar ou atualizar estoque com tratamento de valores negativos
              </p>
              <Button className="w-full bg-purple-600 hover:bg-purple-700">
                Selecionar
              </Button>
            </Card>
          </div>

          {/* Instructions */}
          <Card className="p-6 bg-blue-50 border-blue-200">
            <h3 className="font-semibold text-blue-900 mb-4">💡 Dicas de Importação:</h3>
            <ul className="text-sm text-blue-800 space-y-2 list-disc list-inside">
              <li><strong>Clientes:</strong> Valida CPF/CNPJ automaticamente e normaliza telefones</li>
              <li><strong>Vendas:</strong> Processa compras e atualiza pontos de fidelidade</li>
              <li><strong>Estoque:</strong> Trata valores negativos como 0 e detecta produtos duplicados</li>
              <li>Todos os arquivos devem estar em formato Excel (.xlsx ou .xls)</li>
              <li>Baixe o template para ver o formato esperado de cada tipo</li>
            </ul>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setImportType(null)}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          <h1 className="text-3xl font-bold text-slate-900">
            Importar {importType === 'customers' ? 'Clientes' : importType === 'sales' ? 'Vendas' : 'Estoque'}
          </h1>
          <p className="text-slate-600 mt-2">
            Selecione o arquivo {importType === 'customers' ? 'de cadastro' : importType === 'sales' ? 'de vendas' : 'de estoque'} para importar
          </p>
        </div>

        {/* Main Card */}
        <Card className="p-8 shadow-lg mb-6">
          {/* Message */}
          {message && (
            <div className={`mb-6 p-4 rounded-lg border ${
              status === 'success' ? 'bg-green-50 border-green-200' :
              status === 'error' ? 'bg-red-50 border-red-200' :
              'bg-blue-50 border-blue-200'
            }`}>
              <div className="flex items-center gap-3">
                {status === 'success' && <CheckCircle className="w-5 h-5 text-green-600" />}
                {status === 'error' && <AlertCircle className="w-5 h-5 text-red-600" />}
                <p className={`text-sm ${
                  status === 'success' ? 'text-green-700' :
                  status === 'error' ? 'text-red-700' :
                  'text-blue-700'
                }`}>
                  {message}
                </p>
              </div>
            </div>
          )}

          {/* File Upload */}
          <div className="mb-8">
            <label className="block text-sm font-medium text-slate-700 mb-4">
              Selecione o arquivo Excel
            </label>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-slate-400 transition">
              <Upload className="w-12 h-12 text-slate-400 mx-auto mb-4" />
              <input
                type="file"
                accept=".xlsx,.xls"
                onChange={handleFileChange}
                className="hidden"
                id="file-input"
                disabled={importMutation.isPending}
              />
              <label htmlFor="file-input" className="cursor-pointer">
                <p className="text-sm text-slate-600">
                  {file ? (
                    <span className="font-semibold text-green-600">✓ {file.name}</span>
                  ) : (
                    <>
                      <span className="font-semibold text-slate-900">Clique para selecionar</span>
                      <span className="text-slate-500"> ou arraste o arquivo aqui</span>
                    </>
                  )}
                </p>
              </label>
            </div>
          </div>

          {/* Preview */}
          {preview.length > 0 && (
            <div className="mb-8">
              <h3 className="text-sm font-semibold text-slate-900 mb-3">Prévia dos dados (primeiras 5 linhas):</h3>
              <div className="overflow-x-auto bg-slate-50 rounded-lg p-4">
                <table className="w-full text-xs">
                  <thead>
                    <tr>
                      {Object.keys(preview[0]).map((key) => (
                        <th key={key} className="text-left px-2 py-2 font-semibold text-slate-700 whitespace-nowrap">
                          {key}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {preview.map((row, idx) => (
                      <tr key={idx} className="border-t border-slate-200">
                        {Object.values(row).map((val, i) => (
                          <td key={i} className="px-2 py-2 text-slate-600 whitespace-nowrap">
                            {String(val).substring(0, 30)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-4 pt-6 border-t">
            <Button
              variant="outline"
              onClick={() => setImportType(null)}
              className="flex-1"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <Button
              variant="outline"
              onClick={() => downloadTemplate(importType as 'customers' | 'sales' | 'stock')}
              className="flex-1"
            >
              <Download className="w-4 h-4 mr-2" />
              Baixar Template
            </Button>
            <Button
              onClick={handleImport}
              disabled={!file || importMutation.isPending}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              {importMutation.isPending ? 'Importando...' : 'Importar Dados'}
            </Button>
          </div>
        </Card>

        {/* Instructions */}
        <Card className="p-6 bg-blue-50 border-blue-200">
          <h3 className="font-semibold text-blue-900 mb-4">📋 Requisitos do arquivo:</h3>
          {importType === 'customers' && (
            <ul className="text-sm text-blue-800 space-y-2 list-disc list-inside">
              <li><strong>Obrigatórios:</strong> NOME, CELULAR (ou TELEFONE)</li>
              <li><strong>Opcionais:</strong> CPF, CNPJ, ENDERECO, NUMERO, BAIRRO, CIDADE, SEXO, ESTADO CIVIL, STATUS</li>
              <li>CPF/CNPJ são validados automaticamente</li>
              <li>Telefones são normalizados (remove caracteres especiais)</li>
              <li>Clientes existentes serão atualizados, novos serão criados</li>
            </ul>
          )}
          {importType === 'sales' && (
            <ul className="text-sm text-blue-800 space-y-2 list-disc list-inside">
              <li><strong>Obrigatórios:</strong> NOME, CELULAR (ou TELEFONE), VALOR, DATA PAGO</li>
              <li><strong>Opcionais:</strong> CÓDIGO, NºPEDIDO</li>
              <li>Valores são processados para cálculo de pontos de fidelidade</li>
              <li>Clientes são criados automaticamente se não existirem</li>
              <li>Período: Ago/2024 a Dez/2026 (2.970 registros)</li>
            </ul>
          )}
          {importType === 'stock' && (
            <ul className="text-sm text-blue-800 space-y-2 list-disc list-inside">
              <li><strong>Obrigatórios:</strong> Código, Descrição, Qtd, Unitário (ou À Vista)</li>
              <li><strong>Opcionais:</strong> Cód. Barras, Tam., Cor, Custo, Fornecedor, Categoria, Status, Marca</li>
              <li>Estoques negativos são automaticamente convertidos para 0</li>
              <li>Produtos duplicados são atualizados em vez de criados novamente</li>
              <li>Total: 1.000 produtos no catálogo</li>
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
