import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, TrendingUp, Gift, Zap } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Dashboard() {
  const { data: customers } = trpc.fidelidade.listCustomers.useQuery({ limit: 1000 });
  const { data: rewards } = trpc.fidelidade.listRewards.useQuery();
  const { data: rulesConfig } = trpc.fidelidade.getRulesConfig.useQuery();

  const totalCustomers = customers?.length || 0;
  const totalPointsDistributed = customers?.reduce((sum, c) => sum + (c.totalSpent ? parseInt(c.totalSpent.toString()) : 0), 0) || 0;
  const activeRewards = rewards?.length || 0;

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard de Fidelidade</h1>
          <p className="text-muted-foreground mt-2">Visão geral do programa de fidelidade e cashback</p>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalCustomers}</div>
              <p className="text-xs text-muted-foreground">Clientes cadastrados</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Vendas Totais</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">R$ {totalPointsDistributed.toLocaleString('pt-BR')}</div>
              <p className="text-xs text-muted-foreground">Valor acumulado</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Recompensas Ativas</CardTitle>
              <Gift className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeRewards}</div>
              <p className="text-xs text-muted-foreground">Prêmios disponíveis</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Taxa de Cashback</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{rulesConfig?.bronzeCashback || 5}%</div>
              <p className="text-xs text-muted-foreground">Bronze (padrão)</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Tiers de Fidelidade</CardTitle>
              <CardDescription>Distribuição de clientes por tier</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Bronze</span>
                  <span className="text-sm text-muted-foreground">{customers?.filter(c => c.tier === 'bronze').length || 0}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Prata</span>
                  <span className="text-sm text-muted-foreground">{customers?.filter(c => c.tier === 'prata').length || 0}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Ouro</span>
                  <span className="text-sm text-muted-foreground">{customers?.filter(c => c.tier === 'ouro').length || 0}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Configuração de Pontos</CardTitle>
              <CardDescription>Regras atuais do programa</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Pontos por Real</span>
                  <span className="text-sm text-muted-foreground">{rulesConfig?.pointsPerReal || 1}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Expiração (dias)</span>
                  <span className="text-sm text-muted-foreground">{rulesConfig?.pointsExpirationDays || 90}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Threshold Prata</span>
                  <span className="text-sm text-muted-foreground">R$ {rulesConfig?.prataThreshold || 1500}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
