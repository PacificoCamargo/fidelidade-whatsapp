import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import WhatsAppQRCode from './WhatsAppQRCode';
import WhatsAppPairing from './WhatsAppPairing';

export default function WhatsAppConnect() {
  const [activeTab, setActiveTab] = useState('qrcode');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Conectar WhatsApp</h1>
        <p className="text-muted-foreground mt-2">
          Escolha o método de conexão que preferir
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="qrcode">QR Code</TabsTrigger>
          <TabsTrigger value="pairing">Código de Pareamento</TabsTrigger>
        </TabsList>

        <TabsContent value="qrcode" className="space-y-4">
          <WhatsAppQRCode />
        </TabsContent>

        <TabsContent value="pairing" className="space-y-4">
          <WhatsAppPairing />
        </TabsContent>
      </Tabs>
    </div>
  );
}
