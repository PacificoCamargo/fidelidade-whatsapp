import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Plus } from "lucide-react";

export default function Campaigns() {
  const { data: campaigns, isLoading } = trpc.fidelidade.listCampaigns.useQuery();
  const [showForm, setShowForm] = useState(false);

  const getCampaignTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      reactivation: "Reativação",
      last_chance: "Última Chance",
      nps: "NPS",
      promo: "Promoção",
      birthday: "Aniversário",
      first_purchase: "Primeira Compra",
    };
    return labels[type] || type;
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Campanhas Promocionais</h1>
            <p className="text-muted-foreground mt-2">Gerencie campanhas e promoções do programa</p>
          </div>
          <Button onClick={() => setShowForm(!showForm)}>
            <Plus className="w-4 h-4 mr-2" />
            Nova Campanha
          </Button>
        </div>

        {showForm && (
          <Card>
            <CardHeader>
              <CardTitle>Criar Nova Campanha</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Nome</label>
                  <input type="text" className="w-full border rounded px-3 py-2 mt-1" />
                </div>
                <div>
                  <label className="text-sm font-medium">Tipo</label>
                  <select className="w-full border rounded px-3 py-2 mt-1">
                    <option>Reativação</option>
                    <option>Última Chance</option>
                    <option>NPS</option>
                    <option>Promoção</option>
                    <option>Aniversário</option>
                    <option>Primeira Compra</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Multiplicador de Pontos</label>
                    <input type="number" defaultValue="1" className="w-full border rounded px-3 py-2 mt-1" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Bônus de Cashback (R$)</label>
                    <input type="number" defaultValue="0" className="w-full border rounded px-3 py-2 mt-1" />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button>Criar Campanha</Button>
                  <Button variant="outline" onClick={() => setShowForm(false)}>Cancelar</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Campanhas Ativas</CardTitle>
            <CardDescription>Total: {campaigns?.length || 0} campanhas</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">Carregando...</div>
            ) : !campaigns || campaigns.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Nenhuma campanha cadastrada
              </div>
            ) : (
              <div className="space-y-4">
                {campaigns.map((campaign) => (
                  <div key={campaign.id} className="p-4 border rounded-lg hover:bg-muted/50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold">{campaign.name}</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {getCampaignTypeLabel(campaign.type)}
                          {campaign.segment && ` • Segmento: ${campaign.segment}`}
                        </p>
                        {campaign.messageTemplate && (
                          <p className="text-sm mt-2 p-2 bg-muted rounded">
                            {campaign.messageTemplate}
                          </p>
                        )}
                        <div className="flex gap-2 mt-3">
                          {campaign.pointsMultiplier && campaign.pointsMultiplier > 1 && (
                            <Badge variant="secondary">
                              {campaign.pointsMultiplier}x Pontos
                            </Badge>
                          )}
                          {campaign.cashbackBonus && parseFloat(campaign.cashbackBonus.toString()) > 0 && (
                            <Badge variant="secondary">
                              +R$ {parseFloat(campaign.cashbackBonus.toString()).toFixed(2)} Cashback
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Badge variant={campaign.active ? "default" : "secondary"}>
                        {campaign.active ? "Ativa" : "Inativa"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
