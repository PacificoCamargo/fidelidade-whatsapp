import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, CheckCircle, Loader2, Phone, Copy } from 'lucide-react';
import { trpc } from '@/lib/trpc';

const FIXED_PHONE_NUMBER = '5515996592265';

export default function WhatsAppPairing() {
  const [phoneNumber, setPhoneNumber] = useState(FIXED_PHONE_NUMBER);
  const [pairingCode, setPairingCode] = useState('');
  const [pairingLink, setPairingLink] = useState('');
  const [step, setStep] = useState<'input' | 'pairing' | 'connected'>('input');
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const [shouldCheckStatus, setShouldCheckStatus] = useState(false);

  // Mutations e Queries tRPC
  const initiatePairingMutation = trpc.whatsapp.initiatePairing.useMutation();
  const checkStatusQuery = trpc.whatsapp.checkPairingStatus.useQuery(
    undefined,
    { enabled: shouldCheckStatus, refetchInterval: 2000 }
  );
  const disconnectMutation = trpc.whatsapp.disconnectPairing.useMutation();

  // Verificar status quando conectado
  useEffect(() => {
    if (checkStatusQuery.data?.isConnected && step === 'pairing') {
      setStep('connected');
      setShouldCheckStatus(false);
    }
  }, [checkStatusQuery.data?.isConnected, step]);

  const handleInitiatePairing = async () => {
    setError('');

    try {
      const cleanNumber = FIXED_PHONE_NUMBER;
      if (cleanNumber.length < 10) {
        throw new Error('Número de telefone inválido. Use o formato: 55XXXXXXXXXXX');
      }

      console.log('[WhatsApp Pairing UI] Iniciando pareamento para:', cleanNumber);
      const result = await initiatePairingMutation.mutateAsync({
        phoneNumber: cleanNumber,
      });

      if (result.pairingCode) {
        setPairingCode(result.pairingCode);
        setPairingLink(result.pairingLink);
        setStep('pairing');
        setShouldCheckStatus(true);

        // Parar de verificar após 5 minutos
        setTimeout(() => {
          setShouldCheckStatus(false);
          setError('Tempo limite de pareamento excedido. Tente novamente.');
        }, 5 * 60 * 1000);
      }
    } catch (err: any) {
      setError(err.message || 'Erro ao gerar código de pareamento');
      console.error('Erro:', err);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(pairingCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDisconnect = async () => {
    try {
      await disconnectMutation.mutateAsync();
      setPhoneNumber('');
      setPairingCode('');
      setPairingLink('');
      setStep('input');
      setError('');
      setShouldCheckStatus(false);
    } catch (err: any) {
      setError(err.message || 'Erro ao desconectar');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Conectar WhatsApp</h1>
            <p className="text-muted-foreground mt-2">
              Conecte sua conta WhatsApp usando código de pareamento
            </p>
          </div>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {step === 'input' && (
        <Card>
          <CardHeader>
            <CardTitle>Inserir Número de Telefone</CardTitle>
            <CardDescription>
              Digite seu número de WhatsApp no formato internacional (ex: 5511999999999)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Número de Telefone</label>
              <div className="flex gap-2">
                <Input
                  type="tel"
                  placeholder="55XXXXXXXXXXX"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  disabled={initiatePairingMutation.isPending}
                />
                <Button
                  onClick={handleInitiatePairing}
                  disabled={initiatePairingMutation.isPending || !phoneNumber}
                >
                  {initiatePairingMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Gerando...
                    </>
                  ) : (
                    <>
                      <Phone className="mr-2 h-4 w-4" />
                      Gerar Código
                    </>
                  )}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Seu número deve ter WhatsApp ativo e estar acessível no celular
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {step === 'pairing' && (
        <Card>
          <CardHeader>
            <CardTitle>Código de Pareamento Gerado</CardTitle>
            <CardDescription>
              Use este código para conectar seu WhatsApp
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-muted p-6 rounded-lg text-center">
              <p className="text-sm text-muted-foreground mb-2">Seu código de pareamento:</p>
              <div className="flex items-center justify-center gap-2">
                <p className="text-4xl font-mono font-bold tracking-widest">
                  {pairingCode.split('').join(' ')}
                </p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleCopyCode}
                >
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              {copied && (
                <p className="text-xs text-green-600 mt-2">✓ Código copiado!</p>
              )}
            </div>

            {pairingLink && (
              <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                <p className="text-sm text-blue-900 mb-2">
                  <strong>Link de pareamento:</strong>
                </p>
                <a
                  href={pairingLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 break-all text-sm underline"
                >
                  {pairingLink}
                </a>
              </div>
            )}

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Próximos passos no seu celular:</strong>
                <ol className="list-decimal list-inside mt-2 space-y-1 text-sm">
                  <li>Abra WhatsApp no seu celular</li>
                  <li>Vá em Configurações → Dispositivos Conectados</li>
                  <li>Clique em "Conectar Dispositivo"</li>
                  <li>Selecione "Conectar com Código de Pareamento"</li>
                  <li>Digite o código acima</li>
                </ol>
              </AlertDescription>
            </Alert>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setStep('input');
                  setPairingCode('');
                  setPairingLink('');
                  setPhoneNumber('');
                  setShouldCheckStatus(false);
                }}
              >
                Voltar
              </Button>
              <Button disabled className="flex-1">
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Aguardando pareamento...
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {step === 'connected' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              WhatsApp Conectado!
            </CardTitle>
            <CardDescription>
              Sua conta WhatsApp está pronta para usar
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                Conexão estabelecida com sucesso! Você pode agora enviar mensagens e campanhas via WhatsApp.
              </AlertDescription>
            </Alert>

            <Button
              variant="destructive"
              onClick={handleDisconnect}
              disabled={disconnectMutation.isPending}
            >
              {disconnectMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Desconectando...
                </>
              ) : (
                'Desconectar WhatsApp'
              )}
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
