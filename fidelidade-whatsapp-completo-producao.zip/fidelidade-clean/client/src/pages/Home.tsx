import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  // Redirecionar para dashboard se autenticado
  useEffect(() => {
    if (isAuthenticated && user) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, user, setLocation]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-md w-full space-y-8 text-center">
        <div>
          <h1 className="text-4xl font-bold tracking-tight text-slate-900 mb-2">
            Fidelidade WhatsApp
          </h1>
          <p className="text-lg text-slate-600">
            Sistema de Gestão de Pontos e Cashback para Varejo de Moda
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-8 space-y-6">
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-slate-900">Bem-vindo!</h2>
            <p className="text-slate-600">
              Gerencie seus clientes, pontos, cashback e campanhas promocionais de forma simples e intuitiva.
            </p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-8 w-8 rounded-md bg-blue-500 text-white">
                  ✓
                </div>
              </div>
              <p className="text-sm text-slate-600">Gestão completa de clientes</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-8 w-8 rounded-md bg-blue-500 text-white">
                  ✓
                </div>
              </div>
              <p className="text-sm text-slate-600">Sistema de pontos e cashback</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-8 w-8 rounded-md bg-blue-500 text-white">
                  ✓
                </div>
              </div>
              <p className="text-sm text-slate-600">Integração com WhatsApp</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-8 w-8 rounded-md bg-blue-500 text-white">
                  ✓
                </div>
              </div>
              <p className="text-sm text-slate-600">Automações de envio</p>
            </div>
          </div>

          <a href={getLoginUrl()}>
            <Button className="w-full" size="lg">
              Fazer Login
            </Button>
          </a>
        </div>

        <p className="text-xs text-slate-500">
          Desenvolvido com React, Node.js e WhatsApp Web
        </p>
      </div>
    </div>
  );
}
