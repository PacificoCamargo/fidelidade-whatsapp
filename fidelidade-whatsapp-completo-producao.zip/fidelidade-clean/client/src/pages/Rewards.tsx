import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Plus } from "lucide-react";

export default function Rewards() {
  const { data: rewards, isLoading } = trpc.fidelidade.listRewards.useQuery();
  const [showForm, setShowForm] = useState(false);

  const getRewardTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      discount: "Desconto",
      cashback: "Cashback",
      gift: "Brinde",
      experience: "Experiência",
    };
    return labels[type] || type;
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Recompensas</h1>
            <p className="text-muted-foreground mt-2">Gerencie as recompensas disponíveis no programa</p>
          </div>
          <Button onClick={() => setShowForm(!showForm)}>
            <Plus className="w-4 h-4 mr-2" />
            Nova Recompensa
          </Button>
        </div>

        {showForm && (
          <Card>
            <CardHeader>
              <CardTitle>Criar Nova Recompensa</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Nome</label>
                  <input type="text" placeholder="Ex: Desconto de R$ 50" className="w-full border rounded px-3 py-2 mt-1" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Tipo</label>
                    <select className="w-full border rounded px-3 py-2 mt-1">
                      <option>Desconto</option>
                      <option>Cashback</option>
                      <option>Brinde</option>
                      <option>Experiência</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Valor (R$)</label>
                    <input type="number" placeholder="0.00" className="w-full border rounded px-3 py-2 mt-1" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">Pontos Necessários</label>
                    <input type="number" placeholder="1000" className="w-full border rounded px-3 py-2 mt-1" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Dias de Validade</label>
                    <input type="number" defaultValue="90" className="w-full border rounded px-3 py-2 mt-1" />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button>Criar Recompensa</Button>
                  <Button variant="outline" onClick={() => setShowForm(false)}>Cancelar</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Recompensas Disponíveis</CardTitle>
            <CardDescription>Total: {rewards?.length || 0} recompensas</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">Carregando...</div>
            ) : !rewards || rewards.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Nenhuma recompensa cadastrada
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {rewards.map((reward) => (
                  <Card key={reward.id} className="border">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-base">{reward.name}</CardTitle>
                          <Badge className="mt-2" variant="secondary">
                            {getRewardTypeLabel(reward.type)}
                          </Badge>
                        </div>
                        <Badge variant={reward.active ? "default" : "secondary"}>
                          {reward.active ? "Ativa" : "Inativa"}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <p className="text-sm text-muted-foreground">Valor</p>
                        <p className="text-lg font-semibold">
                          R$ {parseFloat(reward.value.toString()).toFixed(2)}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Pontos Necessários</p>
                        <p className="text-lg font-semibold">{reward.pointsRequired}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Validade</p>
                        <p className="text-sm">{reward.expirationDays} dias</p>
                      </div>
                      <Button className="w-full mt-4" variant="outline" size="sm">
                        Editar
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
