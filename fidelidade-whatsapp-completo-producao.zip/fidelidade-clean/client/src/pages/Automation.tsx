import DashboardLayout from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Plus, Edit2, Trash2, Play, Zap } from "lucide-react";

const TRIGGER_TYPES = {
  points_accumulated: "Pontos Acumulados",
  cashback_available: "Cashback Disponível",
  points_expiring: "Expiração de Pontos",
  birthday: "Aniversário",
  tier_upgrade: "Upgrade de Tier",
  purchase_milestone: "Marco de Compra",
};

export default function Automation() {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    triggerType: "points_accumulated" as keyof typeof TRIGGER_TYPES,
    messageTemplate: "",
  });

  const { data: triggers, refetch } = trpc.automation.listTriggers.useQuery();
  const createMutation = trpc.automation.createTrigger.useMutation();
  const updateMutation = trpc.automation.updateTrigger.useMutation();
  const deleteMutation = trpc.automation.deleteTrigger.useMutation();
  const executeMutation = trpc.automation.executeTriggers.useMutation();

  const handleCreateOrUpdate = async () => {
    if (!formData.name || !formData.messageTemplate) {
      alert("Preencha todos os campos");
      return;
    }

    try {
      if (editingId) {
        await updateMutation.mutateAsync({
          id: editingId,
          name: formData.name,
          messageTemplate: formData.messageTemplate,
        });
      } else {
        await createMutation.mutateAsync({
          name: formData.name,
          triggerType: formData.triggerType,
          messageTemplate: formData.messageTemplate,
        });
      }

      setFormData({ name: "", triggerType: "points_accumulated", messageTemplate: "" });
      setEditingId(null);
      setShowForm(false);
      await refetch();
    } catch (error) {
      alert("Erro ao salvar trigger");
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Tem certeza que deseja deletar este trigger?")) return;

    try {
      await deleteMutation.mutateAsync({ id });
      await refetch();
    } catch (error) {
      alert("Erro ao deletar trigger");
    }
  };

  const handleExecute = async () => {
    try {
      await executeMutation.mutateAsync();
      alert("Triggers executados com sucesso!");
    } catch (error) {
      alert("Erro ao executar triggers");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Automações</h1>
            <p className="text-muted-foreground mt-2">Gerencie triggers de envio automático</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleExecute} disabled={executeMutation.isPending}>
              <Play className="w-4 h-4 mr-2" />
              {executeMutation.isPending ? "Executando..." : "Executar Agora"}
            </Button>
            <Button onClick={() => setShowForm(!showForm)}>
              <Plus className="w-4 h-4 mr-2" />
              Novo Trigger
            </Button>
          </div>
        </div>

        {/* Formulário */}
        {showForm && (
          <Card>
            <CardHeader>
              <CardTitle>{editingId ? "Editar Trigger" : "Novo Trigger"}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Nome</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Ex: Notificação de Pontos"
                  className="mt-1"
                />
              </div>

              <div>
                <label className="text-sm font-medium">Tipo de Trigger</label>
                <select
                  value={formData.triggerType}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      triggerType: e.target.value as keyof typeof TRIGGER_TYPES,
                    })
                  }
                  className="w-full border rounded px-3 py-2 mt-1"
                >
                  {Object.entries(TRIGGER_TYPES).map(([key, label]) => (
                    <option key={key} value={key}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm font-medium">Mensagem</label>
                <p className="text-xs text-muted-foreground mb-2">
                  Variáveis disponíveis: {"{name}"}, {"{points}"}, {"{cashback}"}, {"{tier}"},
                  {"{daysRemaining}"}
                </p>
                <textarea
                  value={formData.messageTemplate}
                  onChange={(e) => setFormData({ ...formData, messageTemplate: e.target.value })}
                  placeholder="Olá {name}! Você acumulou {points} pontos!"
                  className="w-full border rounded px-3 py-2 min-h-24"
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={handleCreateOrUpdate} disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Salvando..." : "Salvar"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowForm(false);
                    setEditingId(null);
                    setFormData({ name: "", triggerType: "points_accumulated", messageTemplate: "" });
                  }}
                >
                  Cancelar
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Lista de Triggers */}
        <div className="grid gap-4">
          {triggers?.triggers && triggers.triggers.length > 0 ? (
            triggers.triggers.map((trigger: any) => (
              <Card key={trigger.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Zap className="w-5 h-5 text-yellow-500" />
                      <div>
                        <CardTitle className="text-lg">{trigger.name}</CardTitle>
                        <CardDescription>
                          {TRIGGER_TYPES[trigger.triggerType as keyof typeof TRIGGER_TYPES]}
                        </CardDescription>
                      </div>
                    </div>
                    <Badge variant={trigger.isActive ? "default" : "secondary"}>
                      {trigger.isActive ? "Ativo" : "Inativo"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-muted rounded text-sm">
                    <p className="font-medium mb-1">Mensagem:</p>
                    <p className="text-muted-foreground">{trigger.messageTemplate}</p>
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Execuções</p>
                      <p className="font-semibold">{trigger.executionCount}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Última execução</p>
                      <p className="font-semibold text-xs">
                        {trigger.lastExecuted
                          ? new Date(trigger.lastExecuted).toLocaleDateString("pt-BR")
                          : "Nunca"}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Próxima execução</p>
                      <p className="font-semibold text-xs">
                        {trigger.nextExecution
                          ? new Date(trigger.nextExecution).toLocaleDateString("pt-BR")
                          : "Em breve"}
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEditingId(trigger.id);
                        setFormData({
                          name: trigger.name,
                          triggerType: trigger.triggerType,
                          messageTemplate: trigger.messageTemplate,
                        });
                        setShowForm(true);
                      }}
                    >
                      <Edit2 className="w-4 h-4 mr-1" />
                      Editar
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDelete(trigger.id)}
                    >
                      <Trash2 className="w-4 h-4 mr-1" />
                      Deletar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="pt-6 text-center text-muted-foreground">
                Nenhum trigger criado ainda. Clique em "Novo Trigger" para começar.
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
