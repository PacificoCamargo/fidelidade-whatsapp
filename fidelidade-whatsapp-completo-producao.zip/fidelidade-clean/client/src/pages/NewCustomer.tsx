import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { trpc } from '@/lib/trpc';
import { format } from 'date-fns';

export default function NewCustomer() {
  const [, setLocation] = useLocation();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    birthDate: '',
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const createCustomerMutation = trpc.fidelidade.createCustomer.useMutation({
    onSuccess: (data) => {
      if (data?.id) {
        setLocation(`/customers/${data.id}`);
      } else {
        setLocation('/customers');
      }
    },
    onError: (err) => {
      setError(err.message || 'Erro ao criar cliente');
    },
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Validar campos
    if (!formData.name.trim()) {
      setError('Nome é obrigatório');
      setIsLoading(false);
      return;
    }

    if (!formData.phone.trim()) {
      setError('Telefone é obrigatório');
      setIsLoading(false);
      return;
    }

    // Formatar telefone
    const cleanPhone = formData.phone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setError('Telefone inválido');
      setIsLoading(false);
      return;
    }

    try {
      await createCustomerMutation.mutateAsync({
        name: formData.name.trim(),
        phone: cleanPhone,
        email: formData.email.trim() || undefined,
        birthDate: formData.birthDate ? new Date(formData.birthDate) : undefined,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Novo Cliente</h1>
          <p className="text-slate-600 mt-2">Cadastre um novo cliente no programa de fidelidade</p>
        </div>

        {/* Form Card */}
        <Card className="p-8 shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Error Message */}
            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}

            {/* Nome */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Nome Completo *
              </label>
              <Input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Ex: Maria Silva"
                className="w-full"
                disabled={isLoading}
              />
            </div>

            {/* Telefone */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Telefone (WhatsApp) *
              </label>
              <Input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                placeholder="Ex: (11) 99999-9999"
                className="w-full"
                disabled={isLoading}
              />
              <p className="text-xs text-slate-500 mt-1">
                Será usado para enviar mensagens e ofertas
              </p>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Email (opcional)
              </label>
              <Input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Ex: maria@email.com"
                className="w-full"
                disabled={isLoading}
              />
            </div>

            {/* Data de Nascimento */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Data de Nascimento (opcional)
              </label>
              <Input
                type="date"
                name="birthDate"
                value={formData.birthDate}
                onChange={handleChange}
                className="w-full"
                disabled={isLoading}
              />
              <p className="text-xs text-slate-500 mt-1">
                Será usado para enviar cupom de aniversário
              </p>
            </div>

            {/* Buttons */}
            <div className="flex gap-4 pt-6 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation('/customers')}
                disabled={isLoading}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                {isLoading ? 'Cadastrando...' : 'Cadastrar Cliente'}
              </Button>
            </div>
          </form>
        </Card>

        {/* Info Box */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-semibold text-blue-900 mb-2">💡 Dica</h3>
          <p className="text-blue-800 text-sm">
            Após cadastrar o cliente, você poderá visualizar seu perfil, histórico de compras,
            pontos acumulados e enviar mensagens personalizadas via WhatsApp.
          </p>
        </div>
      </div>
    </div>
  );
}
