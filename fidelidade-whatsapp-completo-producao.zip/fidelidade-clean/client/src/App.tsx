import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Customers from "./pages/Customers";
import CustomerDetail from "./pages/CustomerDetail";
import Campaigns from "./pages/Campaigns";
import Rewards from "./pages/Rewards";
import Reports from "./pages/Reports";
import Settings from "./pages/Settings";
// import WhatsApp from "./pages/WhatsApp"; // Removido
import Automation from "./pages/Automation";
import NewCustomer from "./pages/NewCustomer";
import WhatsAppConnect from "./pages/WhatsAppConnect";
import ImportData from "./pages/ImportData";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/customers" component={Customers} />
      <Route path="/customers/new" component={NewCustomer} />
      <Route path="/customers/:id" component={CustomerDetail} />
      <Route path="/campaigns" component={Campaigns} />
      <Route path="/rewards" component={Rewards} />
      <Route path="/reports" component={Reports} />
      <Route path="/settings" component={Settings} />
      <Route path="/whatsapp" component={WhatsAppConnect} />
      <Route path="/import" component={ImportData} />
      <Route path="/automation" component={Automation} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
